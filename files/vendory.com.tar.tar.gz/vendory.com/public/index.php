<?php
//
// +---------------------------------------------------------------------------------+
// | Vendory :: main content controller                                              |
// +---------------------------------------------------------------------------------+
// | Copyright (c) 2005 Peachy Conceptual Development LTD. <http://www.peachy.co.nz> |
// +---------------------------------------------------------------------------------+
//

/**
 * This file is the "fat controller" for the entire vendory website. It parses the 
 * query string to determine what page to display.
 * 
 * @author      David Petrie <david@peachy.co.nz>
 * @copyright   Copyright &copy; 2005 Peachy Conceptual Development LTD. <http://www.peachy.co.nz>
 * @license     INTERNAL - NO DISTRIBUTION VIA INTERNET/EMAIL/FTP WITHOUT PRIOR WRITTEN PERMISSION
 * @category    Main page content controller controller.
 * @package     vendory.index
 */
 
require("../config/config.inc.php");

$title = "Vendory Software";

include_once(TOTARA__LOCATION . "totara__Location.inc.php");
include_once(TOTARA__COMMERCE . "totara__OrderSystem.inc.php");
include_once(TOTARA__COMMERCE . "totara__Products.inc.php");
include_once(TOTARA__CONTENT . "totara__Content.inc.php");

$URI_QUERYSTRING = URI_QUERYSTRING();

if (isset($URI_QUERYSTRING[0])) {
	$pageControl = $URI_QUERYSTRING[0];
} else {
	$pageControl = "index";
}



// module format:
//================
//<module>
//  <title></title>
//  <layoutType></layoutType>
//  <logIn group=",,,,">
//    <success></success>
//    <failure></failure>
//  </logIn>
//  <redirect>path_to_url</redirect>
//  <include>modulename</include>
//  <if></if>
//  <else></else>
//</module>


if ("test" == $pageControl) {
		
} else if ("app" == $pageControl) {
	if (0 < strlen($URI_QUERYSTRING[1])) {
		$application = GetApplicationByCode($URI_QUERYSTRING[1]);
		if (false == $application) {
			
		} else {
			header("Location: http://" . $application->urlRoot . "/index");
		}
	} else {
		header("Location: /notfound");
	}
} else if ("account" == $pageControl) {
	$title = "Your Account";
	if (loggedIn(APP_ADMIN_GROUP)) 
	{
		if (1 < count($URI_QUERYSTRING)) {
			$main_include = APP_CONTENT . "account.inc.php";
		} else {
			$main_include = APP_CONTENT . "accounthome.inc.php";
		}
		$layoutType = ACCOUNT_LAYOUT;
	} else {
		header("Location: /login");
	}
} else if ("admin" == $pageControl) {
	$title = "Administration Page";

	// Check if logged in. If not, bump to home page
	if (loggedIn(APP_NORMAL_USERS) || loggedIn(APP_ADMIN_GROUP)) {		
		include(APP_CONTENT . "com_admin.inc.php");
	} else {
		header("Location: /index");
	}
	
	if (IsPrintable()) {
		$layoutType = PRINT_LAYOUT;
	} else {
		$layoutType = ADMIN_LAYOUT;
	}
} else if ("regen" == $pageControl) {
	if (loggedIn(APP_ADMIN_GROUP)) {		
		$groups = GetGroups();
		foreach($groups as $updateGroup) {
			echo $updateGroup->strName . "<br />";
			$groupUsers = GetUsersForGroup($updateGroup->ixGroup, -1, -1);
			if (false != $groupUsers) {
				foreach($groupUsers as $groupUser) {
					$oldChecksum = $groupUser->checksum1;
					if (isset($groupUser->ixUser)) {
						$sec = GetSecurityByID($groupUser->ixUser);
						if (false == $sec) {
							$groupUser->createSecurityObject("password");
							echo "No Security Object found for user: " . $groupUser->ixUser;
						} else {
							$passwordKey = sha1($groupUser->dtCreationDate . $sec["checksum1"]);
							$pass = dbNameClean(DecryptString($passwordKey, $sec["checksum2"]));
							// echo $groupUser->email . ", " . $pass . ", " . sha1($pass) . "<br />";
							$groupUser->createSecurityObject(trim($pass));
						}
						// UpdateUserSecurity($groupUser, $oldChecksum);
					}
				}
			}
		}
	}
} else if ("mhoviestt" == $pageControl) {
	$title = "topten";
	include("promo_topten.inc.php");
	$layoutType = ADMIN_LAYOUT;
} else if ("superadmin" == $pageControl) {
	$title = "Super User Page";

	// Check if logged in. If not, bump to home page
	if (loggedIn(APP_ADMIN_GROUP)) {		
		include(APP_CONTENT . "com_superAdmin.inc.php");
	} else {
		header("Location: /index");
	}
	
	$layoutType = ADMIN_LAYOUT;
} else if ("category" == $pageControl) {
	if(isset($URI_QUERYSTRING[1])) {
		$categoryCode = $URI_QUERYSTRING[1];
		$category = GetCategory($categoryCode);
		$products = GetAllProductsForCategory($categoryCode);
		$title = $category->strName;
	} else {
		$title = "No category found.";
	}
	$main_include = APP_CONTENT . "category.inc.php";
	$layoutType = CATEGORY_LAYOUT;
} else if ("contact" == $pageControl) {
	$title = "Contact Us";

	if (isset($_POST["contact"])) 
	{
		$result = SendContactMessage("contact@fastlogo.co.nz");
		if (true === $result) {
			$main_include = APP_CONTENT . "contactDone.inc.php";
		} else {
			$error = $result;
			$main_include = APP_CONTENT . "contact.inc.php";
		}
	} else {
		$main_include = APP_CONTENT . "contact.inc.php";
	}		
	$layoutType = PAGE_LAYOUT;
} else if ("forgot" == $pageControl) {
	if (isset($_POST["forgot_submit"])) 
	{
		$result = doRetrievePassword();
		if (false === $result || INVALID_EMAIL === $result) {
			$error = 1;
		} else {
			$uEmail = $_POST["email"];
			$sEmail = sStringClean($uEmail);
	
			$subject = "[WebDepot] Information you requested";
			$header="From: " . "info@webdepot.co.nz" . "\r\n" . "Reply-To: " . "info@webdepot.co.nz" . "\r\n" . "X-Mailer: PHP/" . phpversion() . "\nContent-Type: text/html; charset=iso-8859-1";
	
			$message = "This is an automatically generated email. <br><br>\n\n" . 
			"You have requested to receive your password via email:<br><br>\n\n" . $result;
			
			$subject = stripslashes($subject); 
			$message = stripslashes($message); 
	
			mail($sEmail,$subject,$message,$header);
		}
	}
	$title = "Forgot your password?";
	$main_include = APP_VIEWS . "login_ViewForgotPassword.inc.php";
	$layoutType = STANDARD_LAYOUT;
} else if ("fakelogin" == $pageControl) {
	/*if (loggedIn(APP_NORMAL_USERS) || loggedIn(APP_ADMIN_GROUP)) {
		if (isset($URI_QUERYSTRING[1])) {
			if (is_numeric($URI_QUERYSTRING[1])) {
				$groups = GetGroupsForUser($URI_QUERYSTRING[1]);
				$apps = GetApplicationsForGroup($groups[0]->ixGroup);
				$fakeUser = GetUserByID($URI_QUERYSTRING[1], false);
				//HandleSignin($fakeUser->email, $fakeUser->, false, $groups[0]->strCode);
				//header("Location: http://" . $apps[0]->urlRoot . "/index");
				
				
				//	header("Location: http://" . $application->urlRoot . "/index");
				
			}
		}
	}*/
} else if ("index" == $pageControl) {
	$title = "Welcome!";
	$homepage = true;
	$main_include = APP_CONTENT . "home.inc.php";
	$layoutType = HOME_LAYOUT;
	
} else if ("czx152" == $pageControl) {
	if (isset($_POST["login"])) 
	{
		$user = getCurrentUser(APP_ADMIN_GROUP);
		$error = doLogin("/admin", APP_ADMIN_GROUP);
	} 
	else if (loggedIn(APP_ADMIN_GROUP)) 
	{
		header("Location: /admin");
	}
	$title = "Login";
	$formAction = "/czx152";
	$main_include = APP_VIEWS . "login_ViewLogin.inc.php";
	$layoutType = STANDARD_LAYOUT;
} else if ("login" == $pageControl) {
	if (isset($_POST["login"])) 
	{
		$user = getCurrentUser(APP_NORMAL_USERS);
		$error = doLogin("/admin", APP_NORMAL_USERS);
	} 
	else if (loggedIn(APP_NORMAL_USERS)) 
	{
		header("Location: /admin");
	}
	$title = "Login";
	$main_include = APP_VIEWS . "login_ViewLogin.inc.php";
	$layoutType = STANDARD_LAYOUT;
} else if ("order" == $pageControl) {
	$title = "Your Order";
	$main_include = APP_CONTENT . "orderController.inc.php";
	$layoutType = ORDER_LAYOUT;
} else if ("page" == $pageControl) {
	$title = "Page";
	$main_include = TOTARA__CONTENT . "viewPage.inc.php";
	$layoutType = PAGE_LAYOUT;
} else if ("product" == $pageControl) {
	if(isset($URI_QUERYSTRING[1])) {
		$productCode = $URI_QUERYSTRING[1];
		$generic = GetGeneric($productCode);
		if (false === $generic) {
			$title = "No Product Found.";
		} else {
			$product = $generic->product;
			$title = $generic->product->strTitle;
		}
	} else {
		$title = "No product found.";
	}
	$main_include = PEACHY__PRODUCTS . "viewGeneric.inc.php";
	$layoutType = PRODUCT_LAYOUT;
} else if ("productUser" == $pageControl) {
	// Only one thing can be ordered at a time.
	ClearShoppingCart();
	
	// No longer halfway through an order when this happens
	ClearContainer('ORDER_PROGRESS');
	
	if (true == AddToCart()) {
		// Add the order to the database as an uncommitted order.
		// redirect to the product setup pages
		header ("Location: /order");
	} else {
		// log an error
		// redirect back to the product page.
	}
} else if ("register" == $pageControl) {
	if (isset($_POST["doregister"])) 
	{
		$error = registerNewUser("/account");
	} 
	else if (isLoggedIn()) 
	{
		header("Location: /account");
	}
	
	$title = "Login";
	$main_include = APP_VIEWS . "login_ViewRegister.inc.php";
	$layoutType = STANDARD_LAYOUT;
} else if ("signout" == $pageControl) {
	DoLogout();
} else if ("mt" == $pageControl) {
	header("Location: http://old.webdepot.co.nz/mt/mt.cgi");	
} else {
	$title = "Page Could Not Be Found";
	$main_include = APP_CONTENT . "pageNotFound.inc.php";
	$layoutType = PAGE_LAYOUT;
}

include($layoutType);

?>



