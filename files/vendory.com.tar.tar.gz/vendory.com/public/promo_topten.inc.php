<!-- What's new -->
<div align="left" style="margin: 4px 4px 4px 4px; font-size: 11px">
<b>Top sellers this week:</b>
<br /><br />


<?php

$MHDB = GetMoviehouseDB();

$sqlTopten = "select title,movieid as id,sum(orderitem.quantity) as sales from orderitem join f_order "
		. ",movie where orderitem.movieid=movie.id and orderitem.orderid=f_order.id and "
		. "f_order.receivedate>UNIX_TIMESTAMP()-(3600*24*30) group by movieid order by sales"
		. " desc, movieid desc LIMIT 0,10";
		
$movies = $MHDB->query($sqlTopten);

$count = 1;

while ($movieinfo_result = mysql_fetch_array($movies, MYSQL_ASSOC)) {
	// <img height=\"100\" src=\"" . $COVER_PATH . $movieinfo_result["imagename"] . ".jpg\"><br>
	print($count . ".&nbsp;<a href=\"/movie/" . $movieinfo_result["id"] . "\">" . $movieinfo_result["title"] . "</a>");
	print("<br /><br />");
	$count = $count + 1;
}

?>
</div>
<!-- End what's new -->