<?php
	echo "<br /><b>Thanks!</b><br /><br />";
	echo "We should be back to you Real Soon Now, weather permitting.<br /><br />";
?>