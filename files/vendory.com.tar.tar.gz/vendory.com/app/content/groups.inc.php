<?php

include(APP_LAYOUT . 'adminMenu.inc.php');

if (isset($URI_QUERYSTRING[2])) {
	if ("list" == $URI_QUERYSTRING[2]) {
		printGroupsMenu();
		include(TOTARA__KERNAL . "viewGroupsList.inc.php");
	} else if ("create" == $URI_QUERYSTRING[2]) {
		printGroupsMenu();
		include(TOTARA__KERNAL . "viewGroupForm.inc.php");
	} else if ("show" == $URI_QUERYSTRING[2]) {
		printGroupsMenu();
		if (isset($URI_QUERYSTRING[3])) {
			$group = Admin_GetGroupByCode($URI_QUERYSTRING[3], true, false);
			include(TOTARA__KERNAL . "viewGroup.inc.php");
		} else {
			// ERROR - the user id was invalid.
		}
	} else if ("insert" == $URI_QUERYSTRING[2]) {
		if (isset($_POST["submitted"])) {
			$error = true;
			$error = Admin_CreateGroup(GetAdminApplication());
			echo $error;
		}
		header("Location: /admin/groups/list");
	} else if ("edit" == $URI_QUERYSTRING[2]) {
		printGroupsMenu();
		if (isset($URI_QUERYSTRING[3])) {
			$group = Admin_GetGroupByCode($URI_QUERYSTRING[3], false, false);
			if (false != $group) {
				include(TOTARA__KERNAL . "viewGroupForm.inc.php");
			}
		} else {
			// ERROR - the user id was invalid.
		}
	} else if ("update" == $URI_QUERYSTRING[2]) {
		if (isset($_POST["submitted"])) {
			if (isset($URI_QUERYSTRING[3])) {
				$error = true;
				$error = Admin_UpdateGroup($URI_QUERYSTRING[3]);
				header("Location: /admin/groups/edit/" . $URI_QUERYSTRING[3]);
			}
		}
	} else if ("delete" == $URI_QUERYSTRING[2]) {
		if (isset($URI_QUERYSTRING[3])) {
			if (isset($_POST["confirmed"])) {
				$result = Admin_DeleteGroup($URI_QUERYSTRING[3]);
				if ($result) {
					echo "<h4>Supplier was deleted</h4>";
				}
			} else {
				$confirmAction = "/admin/groups/delete/" . $URI_QUERYSTRING[3];
				$actionMessage = "delete this group";
				$buttonMessage = "Delete Group";
				include(TOTARA__KERNAL . "viewConfirm.inc.php");
				
				$group = Admin_GetGroupByCode($URI_QUERYSTRING[3], true, false);
				include(TOTARA__KERNAL . "viewGroup.inc.php");
			}
		} else {
			// ERROR - the group id was invalid.
		}
	} else if ("users" == $URI_QUERYSTRING[2]) {
		printGroupsMenu();
		if (isset($URI_QUERYSTRING[3])) {
			$group = Admin_GetGroupByCode($URI_QUERYSTRING[3], false, false);
			include(TOTARA__KERNAL . "viewSimpleGroup.inc.php");
		} else {
			// fatal error
			header("Location: /admin/app");
		}
		if (isset($URI_QUERYSTRING[4])) {
			if ("list" == $URI_QUERYSTRING[4]) {
				include(TOTARA__KERNAL . "viewUsersList.inc.php");
			} else if ("search" == $URI_QUERYSTRING[4]) {
				if (isset($_POST["query"])) {
					if (0 < strlen($_POST["query"])) {
						$query = $_POST["query"];
					} else {
						$query = "";
					}
				} else if (isset($URI_QUERYSTRING[5])) {
					$query = $URI_QUERYSTRING[5];
				} else {
					$query = "";
				}
				if (isset($URI_QUERYSTRING[6])) {
					if (is_numeric($URI_QUERYSTRING[6])) {
						if (0 >= $URI_QUERYSTRING[6]) {
							$currentPage = 1;
						} else {
							$currentPage = $URI_QUERYSTRING[6];
						}
					} else {
						$currentPage = 1;
					}
				} else {
					$currentPage = 1;
				}
				$start = ($currentPage - 1) * 20;
				$end = $start + 20;
				$users = SearchUsers($group->ixGroup, $query, $start, 20);
				$totalResults = CountUsersInGroup($group->ixGroup);
				$numResults = count($users);
				include(TOTARA__KERNAL . "viewUsersList.inc.php");
			} else if ("create" == $URI_QUERYSTRING[4]) {
				include(TOTARA__KERNAL . "viewUserForm.inc.php");
			} else if ("show" == $URI_QUERYSTRING[4]) {
				if (isset($URI_QUERYSTRING[5])) {
					$user = GetUserByID($URI_QUERYSTRING[5], true);
					include(TOTARA__KERNAL . "viewUser.inc.php");
				} else {
					// ERROR - the user id was invalid.
				}
			} else if ("insert" == $URI_QUERYSTRING[4]) {
				if (isset($_POST["submitted"])) {
					$error = true;	
					$error = Admin_CreateUser($group);
					echo $error;
				}
				header("Location: /admin/groups/users/" . $URI_QUERYSTRING[3] . "/list");
			} else if ("edit" == $URI_QUERYSTRING[4]) {
				if (isset($URI_QUERYSTRING[5])) {
					$user = Admin_GetUser($URI_QUERYSTRING[5]);
					include(TOTARA__KERNAL . "viewUserForm.inc.php");
				} else {
					// ERROR - the user id was invalid.
				}
			} else if ("update" == $URI_QUERYSTRING[4]) {
				
				if (isset($_POST["submitted"])) {
					if (isset($URI_QUERYSTRING[5])) {
						$error = true;
						$error = Admin_UpdateUser($group, $URI_QUERYSTRING[5]);
						// header("Location: /admin/groups/users/" . $URI_QUERYSTRING[3] . "/edit/" . $URI_QUERYSTRING[5]);
					}
				}
			} else if ("delete" == $URI_QUERYSTRING[4]) {
				if (isset($URI_QUERYSTRING[5])) {
					if (isset($_POST["confirmed"])) {
						$result = Admin_DeleteUser($URI_QUERYSTRING[5]);
						if ($result) {
							echo "<h4>User was deleted</h4>";
						}
					} else {
						$confirmAction = "/admin/groups/users/" . $URI_QUERYSTRING[3] . "/delete/" . $URI_QUERYSTRING[5];
						$actionMessage = "delete this user";
						$buttonMessage = "Delete User";
						include(TOTARA__KERNAL . "viewConfirm.inc.php");
						
						$user = GetUserByID($URI_QUERYSTRING[5], true);
						include(TOTARA__KERNAL . "viewUser.inc.php");
					}
				} else {
					// ERROR - the user id was invalid.
				}
			}
		}
	}
} else {
	printGroupsMenu();
	include(TOTARA__KERNAL . "viewGroupsList.inc.php");
}

function printGroupsMenu() {
	$URI_QUERYSTRING = URI_QUERYSTRING();
?>
	<div id="pluginMenu">
	<ul>	
	<li><a href='/admin/groups/list'>All Groups</a></li>
	<li><a href='/admin/groups/create'>Create Group</a></li>
<?php
if (isset($URI_QUERYSTRING[3])) {
	$group = Admin_GetGroupByCode($URI_QUERYSTRING[3], false, false);
	printf("<li><form method='POST' action='/admin/groups/users/%s/search' class='inlineForm'><input name='query' type='text' /><input type='submit' value='Go' /></form></li>", $group->strCode);
}
?>
	</ul>
	</div>
<?
}

?>