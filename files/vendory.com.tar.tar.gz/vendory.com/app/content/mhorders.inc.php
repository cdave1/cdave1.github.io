<?php

if (!IsPrintable()) {
	include(APP_LAYOUT . 'adminMenu.inc.php');
}

include_once(MOVIEHOUSE_1 . "moviehouse.inc.php");

printOrderMenu();
if (isset($URI_QUERYSTRING[2])) {
	if ("current" == $URI_QUERYSTRING[2]) {
		printOutstandingOrders("/admin/mhorders");
	} else if ("remove" == $URI_QUERYSTRING[2]) {
		if (isset($URI_QUERYSTRING[3])) {
			$actionRoot = "/admin/mhorders";
			$order = MH_GetCompleteOrder($URI_QUERYSTRING[3]);
			if (isset($_POST["confirmed"])) {
				MH_DeleteOrder($order);
			} else {
				$confirmAction = "/admin/mhorders/remove/" . $URI_QUERYSTRING[3];
				$actionMessage = "delete this order";
				$buttonMessage = "Delete Order";
				include(TOTARA__KERNAL . "viewConfirm.inc.php");
				include(MOVIEHOUSE_1 . "viewAdminOrder.inc.php");
			}
		}
	} else if ("invoice" == $URI_QUERYSTRING[2]) {
		// execute a statement on the moviehouse inc file to print out an invoice...
		if (isset($URI_QUERYSTRING[3])) {
			$order = MH_GetCompleteOrder($URI_QUERYSTRING[3]);
			include(MOVIEHOUSE_1 . "viewInvoice.inc.php");
		}
	} else if ("changeeta" == $URI_QUERYSTRING[2]) {
		if (isset($URI_QUERYSTRING[3])) {
			if (isset($URI_QUERYSTRING[4])) {
				MH_UpdateOrderETA($URI_QUERYSTRING[3], $URI_QUERYSTRING[4]);
			}
			$actionRoot = "/admin/mhorders";
			$order = MH_GetCompleteOrder($URI_QUERYSTRING[3]);
			include(MOVIEHOUSE_1 . "viewAdminOrder.inc.php");
		}
	} else if ("shipped" == $URI_QUERYSTRING[2]) {
		printShippedOrders("/admin/mhorders");
	} else if ("view" == $URI_QUERYSTRING[2]) {
		if (isset($URI_QUERYSTRING[3])) {
			$actionRoot = "/admin/mhorders";
			$order = MH_GetCompleteOrder($URI_QUERYSTRING[3]);
			include(MOVIEHOUSE_1 . "viewAdminOrder.inc.php");
		}
	} else if ("process" == $URI_QUERYSTRING[2]) {
		if (isset($URI_QUERYSTRING[3])) {
			$actionRoot = "/admin/mhorders";
			$order = MH_GetCompleteOrder($URI_QUERYSTRING[3]);
			
			if (isset($_POST["ProcessOrder"])) {
				$error = MH_SetupShipment($order);
			} else {
				include(MOVIEHOUSE_1 . "viewOrderProcess1.inc.php");
			}
		}
	} else if ("stats" == $URI_QUERYSTRING[2]) {
		MH_printStats();
	}
} else {
	MH_DisplayOrderGeneral("/admin/mhorders");
}

function printOrderMenu() {
	if (!IsPrintable()) {
?>
	<div id="pluginMenu">
	<ul>
	<li><a href="/admin/mhorders/current">Current Orders</a></li>
	<li><a href="/admin/mhorders/shipped">Shipped Orders</a></li>
	<li><a href="/admin/mhorders/stats">Statistics</a></li>
	</ul>
	</div>
	<br />
	<?php
	
	print("<form method='POST' id='form' action='/admin/mhorders/search'>");
	print("Order Search:<input type='text' size='20' style='font-size: 10px; font-family: Arial, Verdana; background-color: #ffc' name='q'");
	if (isset($_POST["q"])) {
		print " value=\"" . $_POST["q"] . "\"";
	}
	print (">");
	print("<input type=\"submit\" style='font-size: 10px; font-family: Arial, Verdana; background-color: #ffc' name='1234' value='go -&gt;'>");
	print("</form>");
	
	?>
<?php	
	}
}

?>