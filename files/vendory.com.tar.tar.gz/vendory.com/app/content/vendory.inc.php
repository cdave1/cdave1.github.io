<?php

include(APP_LAYOUT . 'adminMenu.inc.php');

?>
<br />
<ul>
<li><a href="/admin/vendory/category">Categories</a></li>
<li><a href="/admin/vendory/product">Products</a></li>
<li><a href="/admin/vendory/orders">Orders</a></li>
</ul>
<?php

if ("category" == $section) {
	print "<a href='/admin/vendory/category/list'>All Categories</a><br />";
	print "<a href='/admin/vendory/category/create'>Add Category</a><br />";
	
	if ($commandCode != false) {
		if ("create" == $commandCode) {
			include(TOTARA__COMMERCE . "viewCategoryForm.inc.php");
		} else if ("add" == $commandCode) {
			if (isset($_POST["submitted"])) {
				$error = true;
				$error = CreateCategory();
			}
		} else if ("list" == $commandCode) {
			$categories = Admin_GetApplicationCategories(GetAdminApplication());
			if (false != $categories) {
				foreach($categories as $category) {
					include(TOTARA__COMMERCE . "viewSimpleCategory_Admin.inc.php");
				}
			}
		} else if ("edit" == $commandCode) {
			if (isset($URI_QUERYSTRING[4])) {
				$category = Admin_GetCategory($URI_QUERYSTRING[4]);
				if (false != $category) {
					include(TOTARA__COMMERCE . "viewCategoryForm.inc.php");
				}
			}
		} else if ("update" == $commandCode) {
			if (isset($_POST["submitted"])) {
				if (isset($URI_QUERYSTRING[4])) {
					$error = true;
					$error = EditCategory($URI_QUERYSTRING[4]);
				}
			}
		} else if ("delete" == $commandCode) {
			if (isset($URI_QUERYSTRING[4])) {
				$error = DeleteCategory($URI_QUERYSTRING[4], GetAdminApplication());
			}
		}
	} else {
		$categories = Admin_GetApplicationCategories(GetAdminApplication());
		if (false != $categories) {
			foreach($categories as $category) {
				include(TOTARA__COMMERCE . "viewSimpleCategory_Admin.inc.php");
			}
		}
	}
} else if ("product" == $section) {
	print "<a href='/admin/vendory/product/list'>All Products</a><br />";
	print "<a href='/admin/vendory/product/create'>Add Product</a><br />";
	
	if ($commandCode != false) {
		if ("create" == $commandCode) {
			include(TOTARA__COMMERCE . "viewProductForm.inc.php");
		} else if ("add" == $commandCode) {
			if (isset($_POST["submitted"])) {
				$error = true;
				$error = CreateGenericProduct();
			}
		} else if ("list" == $commandCode) {
			if (isset($URI_QUERYSTRING[4])) {
				$categoryCode = $URI_QUERYSTRING[4];
				$products = Admin_GetProductsForCategory($categoryCode);

				if (false != $products) {
					foreach($products as $product) {
						include(TOTARA__COMMERCE . "viewSimpleProduct_Admin.inc.php");
					}
				}
			} else {
				$products = Admin_GetAllProducts();

				if (false != $products) {
					foreach($products as $product) {
						include(TOTARA__COMMERCE . "viewSimpleProduct_Admin.inc.php");
					}
				}
			}					
		} else if ("edit" == $commandCode) {
			if (isset($URI_QUERYSTRING[4])) {
				$generic = Admin_GetGeneric($URI_QUERYSTRING[4]);
				if (false != $generic) {
					include(TOTARA__COMMERCE . "viewProductForm.inc.php");
				}
			}	
		} else if ("update" == $commandCode) {
			if (isset($URI_QUERYSTRING[4])) {
				$generic = Admin_GetGeneric($URI_QUERYSTRING[4]);
				if (false != $generic) {
					Admin_UpdateGenericProduct($generic);
					header("Location: /admin/vendory/product/edit/" . $URI_QUERYSTRING[3]);
				} else {
					echo "Could not find the product.";
				}
			}
		} else if ("delete" == $commandCode) {
			if (isset($URI_QUERYSTRING[4])) {
				$generic = Admin_GetGeneric($URI_QUERYSTRING[4]);
				if (false != $generic) {
					Admin_DeleteGeneric($generic->product->ixProduct);
				} else {
					echo "Could not find the product.";
				}
			}
		}
	} else {
		$products = Admin_GetAllProducts();

		if (false != $products) {
			foreach($products as $product) {
				include(TOTARA__COMMERCE . "viewSimpleProduct_Admin.inc.php");
			}
		}
	}
} else if ("orders" == $section) {
	include(TOTARA__COMMERCE . "TOTARA__COMMERCE.inc.php");
	print "<a href='/admin/vendory/orders/list'>All Orders</a><br />";
	print "<a href='/admin/vendory/orders/create'>Add Order</a><br />";
	
	if ($commandCode != false) {
		if ("create" == $commandCode) {
			
		} else if ("list" == $commandCode) {
			$offset = -1;
			if (isset($URI_QUERYSTRING[5])) {
				$offset = $URI_QUERYSTRING[5];
			}
			$orders = Admin_GetOrders($offset);
			if (false != $orders) {
				include(TOTARA__COMMERCE . "viewOrderList.inc.php");
			} else {
				print "there are no orders for this application.";
			}
			
		} else if ("view" == $commandCode) {
		
		}
	} else {
		$offset = -1;
		if (isset($URI_QUERYSTRING[4])) {
			$offset = $URI_QUERYSTRING[4];
		}
		$orders = Admin_GetOrders($offset);
		if (false != $orders) {
			foreach($orders as $order) {
				include(TOTARA__COMMERCE . "viewOrderSimple_Admin.inc.php");
			}
		} else {
			print "there are no orders for this application.";
		}
	}
}
?>