<?php

include(APP_LAYOUT . 'adminMenu.inc.php');

if (isset($URI_QUERYSTRING[3])) {
	if ("create" == $URI_QUERYSTRING[3]) {
		printCMSMenu();
		include(TOTARA__CONTENT . "viewPageForm.inc.php");
	} else if ("add" == $URI_QUERYSTRING[3]) {
		if (isset($_POST["submitted"])) {
			$error = true;
			$error = CreatePage();
		}
	} else if ("list" == $URI_QUERYSTRING[3]) {
		printCMSMenu();
		include(TOTARA__CONTENT . "viewPageList.inc.php");
	} else if ("edit" == $URI_QUERYSTRING[3]) {
		printCMSMenu();
		if (isset($URI_QUERYSTRING[4])) {
			$page = Admin_GetPage($URI_QUERYSTRING[4]);
			if (false != $page) {
				include(TOTARA__CONTENT . "viewPageForm.inc.php");
			}
		}
	} else if ("update" == $URI_QUERYSTRING[3]) {
		if (isset($URI_QUERYSTRING[4])) {
			$pageCode = $URI_QUERYSTRING[4];
			if (false != $pageCode) {
				Admin_UpdatePage($URI_QUERYSTRING[4]);
				header("Location: /admin/cms/pages/edit/" . $URI_QUERYSTRING[4]); 
			} else {
				echo "Could not find the page.";
			}
		}
	} else if ("delete" == $URI_QUERYSTRING[3]) {
		if (isset($URI_QUERYSTRING[4])) {
			if (isset($_POST["confirmed"])) {
				Admin_DeletePage($URI_QUERYSTRING[4]);
			} else {
				$confirmAction = "/admin/cms/pages/delete/" . $URI_QUERYSTRING[4];
				$actionMessage = "delete this page";
				$buttonMessage = "Delete Page";
				include(TOTARA__KERNAL . "viewConfirm.inc.php");
			}
		} else {
			echo "Could not find the page.";
		}
	}
} else {
	printCMSMenu();
	include(TOTARA__CONTENT . "viewPageList.inc.php");
}

function printCMSMenu() {
?>
	<div id="pluginMenu">
	<ul>
	<li><a href="/admin/cms/pages">Pages</a></li>
	<li><a href="/admin/cms/pages/create">Create a Page</a></li>
	</ul>
	</div>
<?
}

?>