<h2>Current Applications</h2>

<?php

include(TOTARA__KERNAL . "viewApplicationList.inc.php");

?>