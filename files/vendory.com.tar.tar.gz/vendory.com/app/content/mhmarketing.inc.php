<?php

include(APP_LAYOUT . 'adminMenu.inc.php');

include_once(MOVIEHOUSE_1 . "moviehouse.inc.php");

printMarketingMenu();
if (isset($URI_QUERYSTRING[2])) {
	if ("email" == $URI_QUERYSTRING[2]) {
		include(MOVIEHOUSE_1 . "viewEmailForm.inc.php");
	}
}

function printMarketingMenu() {
?>
	<div id="pluginMenu">
	<ul>
	<li><a href="/admin/mhmarketing/email">Send a Marketing Email</a></li>
	</ul>
	</div>
<?php	
}
		
?>