<?php

include(APP_LAYOUT . 'adminMenu.inc.php');

printCRMMenu();

if (isset($URI_QUERYSTRING[2])) {
	if ("all" == $URI_QUERYSTRING[2]) {
		$messages = GetMessages(GetAdminApplication());
		include(TOTARA__CRM . "viewCRMList.inc.php");
	} else if ("sent" == $URI_QUERYSTRING[2]) {
		$messages = GetMessagesByStatus(GetAdminApplication(), CRM_MESSAGE_SENT);
		include(TOTARA__CRM . "viewCRMList.inc.php");
	} else if ("view" == $URI_QUERYSTRING[2]) {
		if (isset($URI_QUERYSTRING[3])) {
			printMessage($URI_QUERYSTRING[3]);
		}
	} else if ("reply" == $URI_QUERYSTRING[2]) {
		if (isset($URI_QUERYSTRING[3])) {
			if (isset($_POST["submitted"])) {
				$message = GetMessage(GetAdminApplication(), $URI_QUERYSTRING[3]);
				sendReply($URI_QUERYSTRING[3], "starterbase@gmail.com", "David Petrie", $message->strSenderEmail); 
			} else {
				printMessageReply($URI_QUERYSTRING[3]);
			}
		}
	} else if ("delete" == $URI_QUERYSTRING[2]) {
		
	}
} else {
	$messages = GetMessages(GetAdminApplication());
	include(TOTARA__CRM . "viewCRMList.inc.php");
}

function printCRMMenu() {
?>
	<div id="pluginMenu">
	<ul>
	<li><a href="/admin/crm/all">Inbox</a></li>
	<li><a href="/admin/crm/sent">Sent Messages</a></li>
	</ul>
	</div>
<?
}

function printMessage($ixMessage) {
	$message = GetMessage(GetAdminApplication(), $ixMessage);
	
	if (false != $message) {
		print "<a href=\"/admin/crm/reply/" . $message->ixMessage . "\">Reply</a><br /><br />";
			
		print "<b>Received:</b> " . date("H:i, D jS of M Y", $message->dtSent) . "<br />";
		print "<b>From:</b> " . $message->strSenderName . " (" . $message->strSenderEmail . ")<br />";
		print "<b>Subject:</b> " . $message->txtSubject . "</b><br /><br /><table border=1><tr><td>";
		print nl2br(html_entity_decode($message->txtMessage));
		print "</td></tr></table>";
		
		if (CRM_MESSAGE_UNREAD == $message->nStatus) {
			UpdateMessageStatus(GetAdminApplication(), $message->ixMessage, CRM_MESSAGE_READ);
		}
	} else {
		print "Invalid message id.";
	}
}

function printMessageReply($ixMessage) {
	$message = GetMessage(GetAdminApplication(), $ixMessage);
	
	if (false != $message) {
		if (CRM_MESSAGE_UNREAD == $message->nStatus) {
			UpdateMessageStatus(GetAdminApplication(), $message->ixMessage, CRM_MESSAGE_READ);
		}
		print "<form method=\"POST\" action=\"/admin/crm/reply/" . $message->ixMessage . "\">";
		print "<input type=\"hidden\" name=\"submitted\" value=\"" . sha1($message->ixMessage) . "\">";
		
		// This is where a template would work beautifully.
		print "<b>Received:</b> " . date("H:i, D jS of M Y", $message->dtSent) . "<br />";
		print "<b>From:</b> " . $message->strSenderName . " (" . $message->strSenderEmail . ")<br />";
		print "<b>Subject:</b> <input size=\"50\" type=\"text\" name=\"txtSubject\" value=\"RE: " . $message->txtSubject . "\"><br /><br />";
		print "<textarea name=\"txtMessage\" rows=\"20\" cols=\"80\">";
		print "Hi " . $message->strSenderName . ",\r\n";
		print "\r\n";
		print "\r\n";
		print "\r\n";
		print "Best Regards\r\n";
		print "David Petrie\r\n";
		print "www.starterbase.com\r\n";
		print "\r\n";
		print "> =============== ORIGINAL MESSAGE ===============\r\n";
		print "> Received: " . date("H:i, D jS of M Y", $message->dtSent) . "\r\n";
		print "> From: " . $message->strSenderName . "\r\n";
		print "> Subject: " . $message->txtSubject . "\r\n";
		print "> \r\n";
		
		$message = html_entity_decode($message->txtMessage);
		$messagelines = explode("\n", $message);
		foreach($messagelines as $line) {
			if (75 < strlen($line)) {
				$char = 0;
				$ncount = 0;

				while ($ncount < (strlen($line))/70) 
				{
					$substr = substr($line, $char, 70);
					if (70 > strlen($substr)) {
						$endChar = strlen($substr);
					} else {
						$endChar = strrpos($substr, " ");
					}
					print "> " . trim(substr($line, $char, $endChar)) . "\r\n";
					$char = $char + $endChar;
					$ncount += 1;
				}
			} else {
				print "> " . $line . "\r\n";
			}
		}
		print "</textarea><br />";
		print "<input type=\"submit\" value=\"Send Reply\">";
		print "</form>";
	} else {
		print "Invalid message id.";
	}
}

function sendReply($ixMessage, $strSenderEmail, $strSenderName, $strRecipientEmail) {
	$message = new Message(-1, GetAdminApplication(), time(), $strSenderEmail, $strSenderName, $strRecipientEmail, "", "", CRM_MESSAGE_SENT);
	$utxtSubject = $_POST['txtSubject'];
	$utxtMessage = $_POST['txtMessage'];
	
	$stxtSubject = sStringClean($utxtSubject);
	$stxtMessage = sStringClean($utxtMessage);
	
	$message->txtSubject = $stxtSubject;
	$message->txtMessage = $stxtMessage;
	
	SaveMessage($message);
	
	$header="From: " . $strSenderEmail . "\r\n" . "Reply-To: " . $strSenderEmail . "\r\n" . "X-Mailer: PHP/" . phpversion() . "\nContent-Type: text/plain; charset=iso-8859-1";
	
	mail($strRecipientEmail,$stxtSubject,$stxtMessage,$header);
	
	UpdateMessageStatus(GetAdminApplication(), $ixMessage, CRM_MESSAGE_REPLIED);
	
	echo "<h4>Message was successfully sent!</h4>";
}

?>