<?php

include(APP_LAYOUT . 'adminMenu.inc.php');

include_once(MOVIEHOUSE_1 . "moviehouse.inc.php");

printProductMenu();
if (isset($URI_QUERYSTRING[2])) {
	if ("create" == $URI_QUERYSTRING[2]) {
		$formAction = "/admin/mhproducts/create";
		if (isset($_POST["movieForm"])) {
			$result = createMovie("/admin/mhproducts/edit");
			if (is_numeric($result)) {
				echo "Added movie.";
				header("Location: /admin/mhproducts/edit/" . $result);
			} else {
				include(MOVIEHOUSE_1 . "MH_viewMovieForm.inc.php");
			}
		} else {
			include(MOVIEHOUSE_1 . "MH_viewMovieForm.inc.php");
		}
	} else if ("edit" == $URI_QUERYSTRING[2]) {
		if (isset($URI_QUERYSTRING[3])) {
			$movie = MH_GetMovie($URI_QUERYSTRING[3]);
			$formAction = "/admin/mhproducts/edit/" . $movie->id;
			if (isset($_POST["movieForm"])) {
				$error = updateMovie($movie);
				if (0 == strlen($error)) {
					header("Location: /admin/mhproducts/edit/" . $movie->id);
				}
			}
			include(MOVIEHOUSE_1 . "MH_viewMovieForm.inc.php");
		}
	} else if ("remove" ==  $URI_QUERYSTRING[2]) {
		if (isset($URI_QUERYSTRING[3])) {
			if (isset($_POST["confirmed"])) {
				MH_DeleteMovie($URI_QUERYSTRING[3]);
				echo "<h4>Page successfully deleted!</h4>";
			} else {
				$confirmAction = "/admin/mhproducts/remove/" . $URI_QUERYSTRING[3];
				$actionMessage = "delete this movie";
				$buttonMessage = "Delete Movie";
				include(TOTARA__KERNAL . "viewConfirm.inc.php");
			}
		}
	} else if ("search" == $URI_QUERYSTRING[2]) {
		if (isset($_POST["q"])) {
			MH_SearchProducts("/admin/mhproducts/stockupdate/all", $_POST["q"], 0, 10);
		}
	} else if ("stockupdate" == $URI_QUERYSTRING[2]) {
		if (isset($URI_QUERYSTRING[3]) && isset($URI_QUERYSTRING[4])) {
			MH_UpdateStock($URI_QUERYSTRING[3], $URI_QUERYSTRING[4]);
			
			// HACK HACK HACK - 'q' being used too much here.
			if (isset($_POST["q"])) {
				MH_SearchProducts("/admin/mhproducts/stockupdate/all", $_POST["q"], 0, 10);
			} else {
				MH_ViewProduct("/admin/mhproducts/stockupdate/all", $URI_QUERYSTRING[4]);
			}
		}
	} else if ("view" == $URI_QUERYSTRING[2]) {
		if (isset($URI_QUERYSTRING[3])) {
			MH_ViewProduct("/admin/mhproducts/stockupdate/all", $URI_QUERYSTRING[3]);
		}
	} else if ("restock" == $URI_QUERYSTRING[2]) {
		if (isset($URI_QUERYSTRING[3])) {
			MH_UpdateStock("all", $URI_QUERYSTRING[3]);
		}
		LatestOrders();
	} else if ("amazon" == $URI_QUERYSTRING[2]) {
		$formAction = "/admin/mhproducts/amazon";
		include(TOTARA__AMAZON . 'amazon_class.php');
		include(TOTARA__AMAZON . 'amazonDataAccess.inc.php');
		include(TOTARA__AMAZON . "amazonSearch.inc.php");
			
		if (isset($_POST["searchingFirst"]))
		{	
			SearchAmazonDVDs("dvd", "+salesrank", $formAction);
		}
		else if (isset($_POST["searchingSecond"]))
		{
			BlowUpAmazonDVD("dvd", "+salesrank", $formAction);
		}
	} else if ("suppliers" == $URI_QUERYSTRING[2]) {
		if (isset($URI_QUERYSTRING[3])) {
			if (is_numeric($URI_QUERYSTRING[3])) {
				$supplier = MH_GetSupplier($URI_QUERYSTRING[3]);
				if (isset($URI_QUERYSTRING[4])) {
					if ("edit" == $URI_QUERYSTRING[4]) {
						if (isset($_POST["submitted"])) {
							$error = MH_EditSupplier($supplier);
							$supplier =  MH_GetSupplier($URI_QUERYSTRING[3]);
							if (0 < strlen($error)) {
								include(MOVIEHOUSE_1 . "viewSupplierForm.inc.php");
							} else {
								echo "<h4>Supplier edited successfully</h4>";
							}
						} else {
							include(MOVIEHOUSE_1 . "viewSupplierForm.inc.php");
						}	
					} else if ("delete" == $URI_QUERYSTRING[4]) {
						if (isset($_POST["confirmed"])) {
							$result = MH_RemoveSupplier($supplier->id);
							if ($result) {
								echo "<h4>Supplier was deleted</h4>";
							}
						} else {
							$confirmAction = "/admin/mhproducts/suppliers/" . $supplier->id . "/delete/";
							$actionMessage = "delete this supplier";
							$buttonMessage = "Delete Supplier";
							include(TOTARA__KERNAL . "viewConfirm.inc.php");
						}
					} else if ("order" == $URI_QUERYSTRING[4]) {
						DistOrder1($supplier->id);
					} else if ("order2" == $URI_QUERYSTRING[4]) {
						DistOrder2($supplier->id);
					} else if ("order3" == $URI_QUERYSTRING[4]) {
						HandleSupplierMessage();
						DistOrder3($supplier->id);
					}
				} else {
					include(MOVIEHOUSE_1 . "viewSupplier.inc.php");
				}
			} else if ("list" == ($URI_QUERYSTRING[3])) {
				$suppliers = MH_GetSuppliers();
				include(MOVIEHOUSE_1 . "viewSupplierList.inc.php");
			} else if ("create" == ($URI_QUERYSTRING[3])) {
				if (isset($_POST["submitted"])) {
					$error = MH_CreateSupplier();
					if (0 < strlen($error)) {
						include(MOVIEHOUSE_1 . "viewSupplierForm.inc.php");
					} else {
						echo "<h4>Supplier Created!</h4>";
					}
				} else {
					include(MOVIEHOUSE_1 . "viewSupplierForm.inc.php");
				}				
			}
		}
		
		
	} 
}

function SearchAmazonDVDs($sCurrentMode, $sCurrentModeSortType, $formAction) {
	$sUrl  = 'http://webservices.amazon.com/onca/xml3';
	$sUrl .= '?t='. ASSOCIATE_ID;
	$sUrl .= '&dev-t='. DEVELOPER_TOKEN;
	$sUrl .= '&mode=' . $sCurrentMode;
	$sUrl .= '&type=lite&page=1';
	$sUrl .= '&f=xml';
	$sUrl .= '&ResponseGroup=EditorialReview';
	$sUrl .= '&KeywordSearch=';
	// search for PHP Books by default
	if (@$_POST['searchTitle']) {
		$sUrl .= urlencode ($_POST['searchTitle']);	
	} else {
		$sUrl .= 'Jenna Jameson';	
	}
	$sUrl .= '&sort='. $sCurrentModeSortType;

	flush();

	$oAmazon = new Amazon_WebService();
	
	//$oAmazon->fp = fopen ($sUrl, 'r');
	if (!$oAmazon->setInputUrl($sUrl, 20)) {
		die ('cannot open input file. exiting..' . '<a href='. $sUrl .'>@</a>');
	}
	
	// pass the output display template
	$oAmazon->sTemplate = TOTARA__AMAZON . 'dvd_process_layout.php';
	
	if (!$oAmazon->parse()) {
		die ('XMLParse failed');
	}
	
	$iTotalResuls = (int) $oAmazon->arAtribute['TotalResults'];
	
	echo '<p> Displayed '. (int) $oAmazon->iNumResults .' results out of ' . $iTotalResuls .'.</p>';
}

function BlowUpAmazonDVD($sCurrentMode, $sCurrentModeSortType, $formAction) {
	$sUrl  = 'http://webservices.amazon.com/onca/xml3';
	$sUrl .= '?t='. ASSOCIATE_ID;
	$sUrl .= '&dev-t='. DEVELOPER_TOKEN;
	$sUrl .= '&mode=' . $sCurrentMode;
	$sUrl .= '&type=heavy&page=1';
	$sUrl .= '&f=xml';
	$sUrl .= '&ResponseGroup=EditorialReview';
	$sUrl .= '&AsinSearch=';
	// search for PHP Books by default
	if (@$_POST['searchTitle']) {
		$sUrl .= urlencode ($_POST['searchTitle']);	
	} else {
		$sUrl .= 'Jenna Jameson';	
	}
	$sUrl .= '&sort='. $sCurrentModeSortType;
	
	flush();

	$oAmazon = new Amazon_WebService();

	//$oAmazon->fp = fopen ($sUrl, 'r');
	if (!$oAmazon->setInputUrl($sUrl, 20)) {
		die ('cannot open input file. exiting..' . '<a href='. $sUrl .'>@</a>');
	}

	// pass the output display template
	$oAmazon->sTemplate = TOTARA__AMAZON . 'amazon_layout.php';
	
	if (!$oAmazon->parse()) {
		die ('XMLParse failed');
	}
}

function printProductMenu() {
?>
	<div id="pluginMenu">
	<ul>
	<li><a href="/admin/mhproducts/create">Add a movie</a></li>
	<li><a href="/admin/mhproducts/restock">Restocks</a></li>
	<li><a href="/admin/mhproducts/suppliers/list">Suppliers</a></li>
	<li><a href="/admin/mhproducts/amazon">Amazon Database</a></li>
	<li><?php printSearchArea(); ?></li>
	</ul>
	</div>
	<?php
}

function printSearchArea() {	
	print("<form method='POST' class='inlineForm' action='/admin/mhproducts/search'>");
	print("Stock Search:<input type='text' size='20' style='font-size: 10px; font-family: Arial, Verdana; background-color: #ffc' name='q'");
	if (isset($_POST["q"])) {
		print " value=\"" . $_POST["q"] . "\"";
	}
	print (">");
	print("<input type=\"submit\" style='font-size: 10px; font-family: Arial, Verdana; background-color: #ffc' name='1234' value='go -&gt;'>");
	print("</form>");
}

// ================================================================================
// Prints movies from an order.
// ================================================================================
function LatestOrders () {
	$DB = GetMoviehouseDB();
	
	print ("<h4>Orders Today:</h4>");

	$distributor_query = $DB->query("select * from distributor");

	while ($distributors = mysql_fetch_array($distributor_query)) {
		print "Order <a href=\"/admin/mhproducts/suppliers/" . $distributors["id"] . "/order\">" . $distributors["name"] . "</a>";
		print "<br />";
	}

	$order_movies = $DB->query("select id from movie where reorderquantity>0");
	$count = 1;
	while ($movies = mysql_fetch_array($order_movies)) {
		MH_ViewProduct("/admin/mhproducts/restock", $movies["id"]);
	}
	$count = $count + 1;
}

// ================================================================================
// This lists all DVDs that are to be added to the supplier order
// ================================================================================
function DistOrder1($distid) {
	$DB = GetMoviehouseDB();

	$distributor_query = $DB->query("select * from distributor where id = " . $distid);

	$distributor = mysql_fetch_array($distributor_query);

	print ("<h4>Orders For " . $distributor["name"] . " - Step 1</h4>");

	print("<table width=\"100%\" cellpadding=\"4\" bgcolor=\"#cccccc\" style=\"border: 1px solid #cccccc\">");

	print("<tr><td bgcolor=\"#ffffff\"><br>");

	$order_movies = $DB->query("select movie.*, movieprice.price, movieprice.di_price, movieprice.di_code, movieprice.rr_price, movieprice.distributorid from movie join movieprice where movie.id = movieprice.movieid and distributorid = " . $distributor["id"] . " and reorderquantity>0");
	$count = 1;
	$profit = 0;

	print("<form method=\"POST\" action=\"/admin/mhproducts/suppliers/" . $distid . "/order2\"><input type=\"submit\" value=\"NEXT\"></form>");
	
	while ($movies = mysql_fetch_array($order_movies)) {
		print("<br>");

		print ("<table border=\"0\" width=\"100%\"><tr><td align=\"left\" width=\"100%\">");

		print("<b><a href=\"/movie?id=" . $movies["id"]  . "\">" . $movies["title"] . "</a></b>");
		print("<br>");
		// Get a list of prices for this product. This assumes that the prices are in order.
		$price = $DB->query("SELECT * FROM movieprice WHERE movieid=" . $movies["id"]);
	
		while ($price_result = mysql_fetch_array($price, MYSQL_ASSOC)) {
			print "Our Price: <b>$" . sprintf("%01.2f", $price_result["price"]) . "</b><br>";
			print "Dist Price: <b>$" . sprintf("%01.2f", $price_result["di_price"]) . "</b><br>";
			print "Profit: <b style=\"color:green\">$" . sprintf("%01.2f", ($price_result["price"] - ($price_result["di_price"] * 1.125))) . "</b><br>";
			print "Dist Code: <b>" . $price_result["di_code"] . "</b><br>";
			$profit = $profit + ($price_result["price"] - ($price_result["di_price"] * 1.125));
		}
		$count = $count + 1;

		print("Quantity: " . abs($movies["reorderquantity"]) . "<br />");
		print("<br />");
		print("</td></tr></table>");
		print ("</form>");
	}
	$count = $count + 1;
	print "Total Profit: $" . sprintf("%01.2f", $profit);
	print ("</td></tr></table>");	
}

// ================================================================================
// Prints complete member list
// ================================================================================
function DistOrder2($distid) {
	$DB = GetMoviehouseDB();

	$distributor_query = $DB->query("select * from distributor where id = " . $distid);

	$distributor = mysql_fetch_array($distributor_query);

	print ("<h4>Email to be sent to " . $distributor["name"] . " - Step 2</h4>");

	print("<table width=\"100%\" cellpadding=\"4\" bgcolor=\"#cccccc\" style=\"border: 1px solid #cccccc\">");

	print("<tr><td bgcolor=\"#ffffff\"><br>");

	$order_movies = $DB->query("select movie.*, movieprice.price, movieprice.di_price, movieprice.di_code, movieprice.rr_price, movieprice.distributorid from movie join movieprice where movie.id = movieprice.movieid and distributorid = " . $distributor["id"] . " and reorderquantity>0");
	$count = 1;

	$email = "";

	print "<b>To</b>: " . $distributor["contactemail"] . "<br />";
	print "<b>Subject</b>: Orders for " . $distributor["accountnumber"] . "<br /><br /><hr />";

	$email = $email . "Hi there,<br><br>";
	$email = $email . "Account Name: " . $distributor["accountname"] . "<br />";
	$email = $email . "Account No.: " . $distributor["accountnumber"] . "<br />";

	$email = $email . "This order is for the following DVDs:<br /><br />";

	while ($movies = mysql_fetch_array($order_movies)) {
		$email = $email . $count . ". <b>" . $movies["title"] . "</b>";
		$email = $email . "<br>";
		// Get a list of prices for this product. This assumes that the prices are in order.
		$price = $DB->query("SELECT * FROM movieprice WHERE movieid=" . $movies["id"]);
	
		while ($price_result = mysql_fetch_array($price, MYSQL_ASSOC)) {
			$email = $email . "Product Code: <b>" . $price_result["di_code"] . "</b><br>";
		}
		$count = $count + 1;

		$email = $email . "Quantity: " . abs($movies["reorderquantity"]) . "<br><br>";
	}
	$email = $email . "<br>Thanks<br>Donald Harmen<br>Moviehouse<br>";
	print $email;

	print "<hr />";

	print "<form method=\"POST\" action=\"/admin/mhproducts/suppliers/" . $distid . "/order3\">";
	print("<input type=\"hidden\" name=\"message\" value=\"" . $email . "\">");
	print("<input type=\"hidden\" name=\"subject\" value=\"" . "Orders for " . $distributor["accountnumber"] . "\">");
	print("<input type=\"hidden\" name=\"distid\" value=\"" . $distid . "\">");
	print("To send email to supplier click here: <input type=\"submit\" value=\"NEXT\">");
	print "</form>";

	print ("</td></tr></table>");
}

function HandleSupplierMessage() {
	$DB = GetMoviehouseDB();

	$query = $_POST['message'];

	$distid = $_POST["distid"];
	$distributor_query = $DB->query("select * from distributor where id = " . $distid);
	$distributor = mysql_fetch_array($distributor_query);
	
	$header="From: Donald Harman <donald@moviehouse.co.nz>\r\n" . "Reply-To: donald@moviehouse.co.nz\r\n" . "X-Mailer: PHP/" . phpversion() . "\nContent-Type: text/html; charset=iso-8859-1";
	$Subject = $_POST["subject"];
	
		$message = "";
		$message = $message . $query;
	
		$recipient = $distributor["contactemail"];
	
		$subject = stripslashes($Subject); 
	        $message = stripslashes($message); 
	
		mail($recipient,$Subject,$message,$header);
		mail("david@peachy.co.nz",$Subject,$message,$header);
	
	// Redirect to the order manager
	
	$supplierorderquery = mysql_query("insert into supplierorder values(0, " . time() . ", " . $distid . ", 0)");
	
	$supplierorderid = mysql_insert_id();
	
	$order_movies = $DB->query("select movie.*, movieprice.price, movieprice.di_price, movieprice.di_code, movieprice.rr_price, movieprice.distributorid from movie join movieprice where movie.id = movieprice.movieid and distributorid = " . $distributor["id"] . " and reorderquantity>0");
	
	while ($movies = mysql_fetch_array($order_movies)) {
		$supplierorderitemquery = mysql_query("insert into supplierorderitem values(" . $supplierorderid . ", " . $movies["id"] . ", " . abs($movies["reorderquantity"]) . ", 0)");
		$updatemoviequantity = mysql_query("update movie set reorderquantity = 0 where movie.id = " . $movies["id"]);
	}
}

// ================================================================================
// Prints complete member list
// ================================================================================
function DistOrder3() {
	$DB = GetMoviehouseDB();

	$all_orders = $DB->query("select supplierorder.*, distributor.name from supplierorder join distributor where distributor.id = supplierorder.distributorid order by createdate desc limit 10");

	$num_rows = mysql_num_rows($all_orders);

	

	if ($num_rows > 0) {
		print ("<h4>Outstanding Supplier Orders</h4>");
		print ("<table width=\"100%\" cellpadding=\"4\" bgcolor=\"#cccccc\" style=\"border: 1px solid #cccccc\">");

		print("<tr><td><b>Order ID</b></td><td><b>Date</b></td><td><b>Status</b></td><td><b>Supplier</b></td></tr>");

		while ($orders = mysql_fetch_array($all_orders)) {
			print("<tr><td colspan=\"4\" bgcolor=\"#990000\"><img src=\"/images/\" height=\"1\"></td></tr>");
			print("<td><a href=\"/admin_124/managerOutput?command=30&id=" . $orders["id"] . "\">" . $orders["id"] . "</td>");
			
			print("<td bgcolor=\"#ffffff\"><small>" . date("D jS of M" , $orders["createdate"]) . "</small></td>");

			print("<td bgcolor=\"#ffffff\">");

			if ($orders["status"] == 0) {
				print("Sent to Supplier");
			} else if ($orders["status"] == 1) {
				print("Received");
			} else {
				print("Shipped");
			}

			print("</td>");
			
			print("<td bgcolor=\"#ffffff\">" . $orders["name"] . "</td></tr>");

			print ("<tr><td colspan=\"2\" bgcolor=\"#eeeeee\">&nbsp;</td><td colspan=\"5\" width=\"100%\" bgcolor=\"#ffffff\">");

			$order_movies = $DB->query("select * from supplierorderitem where supplierorderid = " . $orders["id"]  . " and itemstatus <> 2");

		if (0 == mysql_num_rows($order_movies)) {
			print "<small><b style=\"background:gray; color:white\">All DVDs in this order have shipped.</b><br /><br /><br /><br />";
		} else {

			$count = 1;
			while ($movies = mysql_fetch_array($order_movies)) {
				$movie = $DB->query("select id,title from movie where id = " . $movies["movieid"]);

				$movie_info = mysql_fetch_array($movie);

				print("<small><b>" . $count . ".</b>&nbsp;<a href=\"/movie?id=" . $movie_info["id"]  . "\">" . $movie_info["title"] . "</a>");
				print("&nbsp;x" . $movies["quantity"] . "&nbsp;-&nbsp;");

				if ($movies["itemstatus"] == 0) {
					print("<b style=\"background:red; color:white\">Sent to distributor</b>");
				} 

				if ($movies["itemstatus"] == 1) {
					print("Delivered");
				} 
				
				if ($movies["itemstatus"] == 2) {
					print("Back order");
				} 
				
				if ($movies["itemstatus"] == 3) {
					print("Shipped to customer");
				}
				print("</small><br>");
				$count = $count + 1;
			}
		}
			print("</small><br></td></tr>");
		}
		print ("</table>");
	}	
}

?>