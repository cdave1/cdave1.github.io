<?php
// This is a secure area, and the credentials of the logged in user must
// be checked before any access is granted. The specific credential:
// - does the user belong to a group that is able to make changes to this section
// 
// The user can only edit things relevant to the group. 

// Set the current application up here.
$currentApplication = false;
$currUser = GetCurrentUser();
$allApplications = GetApplicationsForUser($currUser->ixUser);
if (0 < count($allApplications) && false != $allApplications) {
	foreach($allApplications as $app) {
		if (GetAdminApplication() == $app->strCode) {
			$currentApplication = $app;
		}
	}
}
$URI_QUERYSTRING = URI_QUERYSTRING();

// redir if no app selected.
if (false == GetActiveApplication()) {
	if (isset($URI_QUERYSTRING[2])) {
		if ("apps" != $URI_QUERYSTRING[1] && "change" != $URI_QUERYSTRING[2]) {
			$URI_QUERYSTRING = array("admin");
		}
	} else {
		$URI_QUERYSTRING = array("admin");
	}
}

if (isset($URI_QUERYSTRING[1])) {
	if (false == $URI_QUERYSTRING[1]) {
		$mainInclude = APP_CONTENT . "adminHome.inc.php";
	} else if ("home" == $URI_QUERYSTRING[1]) {
		$mainInclude = APP_CONTENT . "adminHome.inc.php";
	} else if ("apps" == $URI_QUERYSTRING[1]) {
		if (isset($URI_QUERYSTRING[2])) {
			if ("change" == $URI_QUERYSTRING[2]) {
				if (isset($_POST["ixfCurrentApplication"])) {
					SetAdminApplication($_POST["ixfCurrentApplication"]);
					header("Location: /admin/apps/show");
				} else if (isset($URI_QUERYSTRING[3])) {
					SetAdminApplication($URI_QUERYSTRING[3]);
					header("Location: /admin/apps/show");		
				}
			}
		}
		$mainInclude = APP_CONTENT . "applications.inc.php";
	} else {
		if ("cms" == $URI_QUERYSTRING[1]) {
			$mainInclude = APP_CONTENT . "cms.inc.php";
		} else if ("questionnara" == $URI_QUERYSTRING[1]) {
			$mainInclude = APP_CONTENT . "questionnara.inc.php";
		} else if ("mhorders" == $URI_QUERYSTRING[1]) {
			$mainInclude = APP_CONTENT . "mhorders.inc.php";
		} else if ("mhproducts" == $URI_QUERYSTRING[1]) {
			$mainInclude = APP_CONTENT . "mhproducts.inc.php";
		} else if ("mhmarketing" == $URI_QUERYSTRING[1]) {
			$mainInclude = APP_CONTENT . "mhmarketing.inc.php";
		} else if ("groups" == $URI_QUERYSTRING[1]) {
			$mainInclude = APP_CONTENT . "groups.inc.php";
		} else if ("bugs" == $URI_QUERYSTRING[1]) {
			$mainInclude = APP_CONTENT . "bugs.inc.php";
		} else if ("help" == $URI_QUERYSTRING[1]) {
			$mainInclude = APP_CONTENT . "help.inc.php";
		} else if ("crm" == $URI_QUERYSTRING[1]) {
			$mainInclude = APP_CONTENT . "crm.inc.php";
		} else {
			header("Location: /admin/apps/list");
		}
	}
} else {
	$mainInclude = APP_CONTENT . "adminHome.inc.php";
}

?>