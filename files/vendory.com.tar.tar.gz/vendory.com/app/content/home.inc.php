<h2>Vendory - The eCommerce Platform</h2>
<br /><br />
<?php //echo sha1("eA348bb541"); ?>