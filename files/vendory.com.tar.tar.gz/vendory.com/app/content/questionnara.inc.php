<?php

include(APP_LAYOUT . 'adminMenu.inc.php');

include(PEACHY__QUESTIONNAIRE . "peachy__Questionnaire.inc.php");
print "<a href='/admin/questionnara/questionnaire/list'>All Questionnaires</a><br />";
print "<a href='/admin/questionnara/questionnaire/create'>Add Questionnaire</a><br />";

if ("questionnaire" == $section) {
	if ("create" == $commandCode) {
		include(PEACHY__QUESTIONNAIRE . "viewQuestionnaireForm_admin.inc.php");
	} else if ("add" == $commandCode) {
		if (isset($_POST["submitted"])) {
			$error = true;
			$error = CreateQuestionnaire();
		}
	} else if ("list" == $commandCode) {
		
		$questionnaires = Admin_GetQuestionnaires(GetAdminApplication());
		if (false != $questionnaires) {
			foreach($questionnaires as $questionnaire) {
				include(PEACHY__QUESTIONNAIRE . "viewSimpleQuestionnaire_Admin.inc.php");
			}
		} else {
			echo "could not retrieve questionnaires.";
		}
	} else if ("edit" == $commandCode) {
		if (isset($URI_QUERYSTRING[4])) {
			$questionnaire = Admin_GetQuestionnaire($URI_QUERYSTRING[4]);
			if (false != $questionnaire) {
				include(PEACHY__QUESTIONNAIRE . "viewQuestionnaireForm_admin.inc.php");
			}
		}
	} else if ("update" == $commandCode) {
		if (isset($URI_QUERYSTRING[4])) {
			$strixCode = $URI_QUERYSTRING[4];
			if (isset($_POST["submitted"])) {
				$error = true;
				$error = adminUpdateQuestionnaire($strixCode);
			}
		}
	} else {
		$questionnaires = Admin_GetQuestionnaires(GetAdminApplication());
		if (false != $questionnaires) {
			foreach($questionnaires as $questionnaire) {
				include(PEACHY__QUESTIONNAIRE . "viewSimpleQuestionnaire_Admin.inc.php");
			}
		} else {
			echo "could not retrieve questionnaires.";
		}
	}
}
?>