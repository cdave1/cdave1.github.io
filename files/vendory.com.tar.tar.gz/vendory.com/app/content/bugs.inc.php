<?php

include(APP_LAYOUT . 'adminMenu.inc.php');

?>
	<div id="pluginMenu">
&nbsp;
	</div>
	<h2>Bug Inserter</h2>
	
<a href='http://www.starterbase.com/rss/6896f6a5380f1a052ba2ebf59e285b7648c28048'>RSS Feed</a>
<br />
	
<script type="text/javascript"><!--
var sbAccount = "6896f6a5380f1a052ba2ebf59e285b7648c28048";
var sbWidth = 700;
var sbHeight = 900;
//--></script>
<script src="http://www.starterbase.com//form.js" type="text/javascript">
</script>