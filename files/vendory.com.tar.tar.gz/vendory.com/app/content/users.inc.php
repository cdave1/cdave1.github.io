<?php

include(APP_LAYOUT . 'adminMenu.inc.php');

if ("users" == $section) {
	if ($commandCode != false) {
		if ("list" == $commandCode) {
			printApplicationsMenu();
			printConfigurationMenu();
			include(TOTARA__KERNAL . "viewUsersList.inc.php");
		} else if ("create" == $commandCode) {
			printApplicationsMenu();
			printConfigurationMenu();
			include(TOTARA__KERNAL . "viewUserForm.inc.php");
		} else if ("show" == $commandCode) {
			printApplicationsMenu();
			printConfigurationMenu();
			if (isset($URI_QUERYSTRING[4])) {
				$user = Admin_GetUser($URI_QUERYSTRING[4]);
				include(TOTARA__KERNAL . "viewUser.inc.php");
			} else {
				// ERROR - the user id was invalid.
			}
		} else if ("insert" == $commandCode) {
			if (isset($_POST["submitted"])) {
				$error = true;
				
				$error = Admin_CreateUser(GetAdminApplication());
				echo $error;
			}
			header("Location: /admin/applications/users/list");
		} else if ("edit" == $commandCode) {
			printApplicationsMenu();
			printConfigurationMenu();
			if (isset($URI_QUERYSTRING[4])) {
				$user = Admin_GetUser($URI_QUERYSTRING[4]);
				include(TOTARA__KERNAL . "viewUserForm.inc.php");
			} else {
				// ERROR - the user id was invalid.
			}
		} else if ("update" == $commandCode) {
			if (isset($_POST["submitted"])) {
				if (isset($URI_QUERYSTRING[4])) {
					$error = true;
					$error = Admin_UpdateUser($URI_QUERYSTRING[4]);
					//header("Location: /admin/applications/users/edit/" . $URI_QUERYSTRING[4]);
				}
			}
		} else if ("delete" == $commandCode) {
			if (isset($URI_QUERYSTRING[4])) {
				Admin_DeleteUser($URI_QUERYSTRING[4]);
				header("Location: /admin/applications/users/list");
			} else {
				// ERROR - the user id was invalid.
			}
		}
	}
}

function printConfigurationMenu() {

}

?>