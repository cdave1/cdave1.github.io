<?php

include(APP_LAYOUT . 'adminMenu.inc.php');

?>
<div class="adminPage">
<?

if (isset($URI_QUERYSTRING[2])) {
        if ("list" == $URI_QUERYSTRING[2]) {
                include(TOTARA__KERNAL . "viewApplicationList.inc.php");
        } else if ("show" == $URI_QUERYSTRING[2]) {
                printApplicationsMenu();
                if (isset($URI_QUERYSTRING[3])) {
                        $application = Admin_GetApplication($URI_QUERYSTRING[3]);
                        include(TOTARA__KERNAL . "viewApplication.inc.php");
                } else {
                        // ERROR - the application code was invalid.
                }
        } else if ("create" == $URI_QUERYSTRING[2]) {
                include(TOTARA__KERNAL . "viewApplicationForm.inc.php");
        } else if ("insert" == $URI_QUERYSTRING[2]) {
                if (isset($_POST["submitted"])) {
                        $error = true;
                        $error = Admin_CreateApplication();
                        echo $error;
                }
              //  header("Location: /admin/apps/list");
        } else if ("edit" == $URI_QUERYSTRING[2]) {
                if (isset($URI_QUERYSTRING[3])) {
                        $application = Admin_GetApplication($URI_QUERYSTRING[3]);
                        include(TOTARA__KERNAL . "viewApplicationForm.inc.php");
                } else {
                        // ERROR - the application code was invalid.
                }
        } else if ("update" == $URI_QUERYSTRING[2]) {
                if (isset($_POST["submitted"])) {
                        if (isset($URI_QUERYSTRING[3])) {
                                $error = true;
                                $error = Admin_UpdateApplication($URI_QUERYSTRING[3]);
                                header("Location: /admin/apps/edit/" . $URI_QUERYSTRING[3]);
                        }
                }
        } else if ("change" == $URI_QUERYSTRING[2]) {
                if (isset($_POST["strAppCode"])) {
                        SetAdminApplication($_POST["strAppCode"]);
                        header("Location: /admin/apps");
                } else if (isset($URI_QUERYSTRING[3])) {
                        SetAdminApplication($URI_QUERYSTRING[3]);
                        header("Location: /admin/apps");        
                }
        }       
} else {
        include(TOTARA__KERNAL . "appHome.inc.php");
}

function printApplicationsMenu() {
        print "<div>";
        print "<ul id='plugins'>";
        print "<li><a href='/admin/apps'>Configuration</a></li>";
        print "<li><a href='/admin/vendory'>Vendory Lite</a></li>";
        print "<li><a href='/admin/cms'>CMS</a></li>";
        print "<li><a href='/admin/questionnara'>Questionnara</a></li>";
        print "</ul>";
        print "</div>";
}

?>
</div>