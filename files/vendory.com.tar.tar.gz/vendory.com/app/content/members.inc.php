<?php

include(APP_LAYOUT . 'adminMenu.inc.php');

print "<a href='/admin/members/list'>All Members</a><br />";
if ($commandCode != false) {
	$users = GetUsersForApplication("", -1, -1, GetAdminApplication());
	if ("list" == $commandCode) {
		if (false != $users) {
			foreach($users as $user) {
				$mainInclude = APP_CONTENT . "viewSimpleUser_Admin.inc.php";
			}
		}
	}
}

?>