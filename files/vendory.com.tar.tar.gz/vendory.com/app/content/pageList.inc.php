<table width="75%" cellspacing="0" class="list" summary="Page List">

<tr class="headerRow">
<th>Title</th>
<th>Category</th>
<th>Last Modified</th>
<th>Author</th>
<th>Status</th>
<th>Delete</th>
<tr>

<?php

$pages = Admin_GetApplicationPages(GetAdminApplication());
if (false != $pages) {
	$nCount = 0;
	foreach($pages as $page) {
		if (1 == $nCount%2) {
			printf("<tr class='normalRow'>");
		} else {
			printf("<tr class='alternateRow'>");
		}
		printf("<td><a href='/admin/cms/pages/edit/%s'>%s</a>", $page->strUniqueCode, $page->strTitle);
		//printf("<br /><br /><small>&raquo;&nbsp;<a href='/admin/cms/pages/comments/%s'>List Comments</a></small>", $page->strUniqueCode);
		printf("</td>");
		printf("<td></td>");
		printf("<td>%s</td>", date("H:i, D jS of M Y", $page->dtLastModified));
		printf("<td>%s</td>", $page->usrfLastEditedBy);
		printf("<td>%s</td>", $page->nStatus);
		printf("<td><a href='/admin/cms/pages/delete/%s'>x</a></td>", $page->strUniqueCode);
		printf("</tr>");
		$nCount += 1;
	}
}

?>
</table>