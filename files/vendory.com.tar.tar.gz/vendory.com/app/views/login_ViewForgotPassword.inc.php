<h2>Forgot Your Password?</h2>

<p>Your password will be emailed to the address you enter below.</p>

<?
include (TOTARA__KERNAL . "viewForgotpassword.inc.php"); 
?>