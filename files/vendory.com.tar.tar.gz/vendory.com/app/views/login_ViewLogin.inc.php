<h1>SUPER DUPER SECRET SIGN IN</h1>
<?
include (TOTARA__KERNAL . "viewLogin.inc.php"); 
?>
<br />

<a href="/forgot">Click here if you have forgotten your password.</a>

<br /><br />