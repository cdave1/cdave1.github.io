<?php
//
// +---------------------------------------------------------------------------------+
// | Peachy :: Product :: test :: Product Test Cases                                 |
// +---------------------------------------------------------------------------------+
// | Copyright (c) 2005 Peachy Conceptual Development LTD. <http://www.peachy.co.nz> |
// +---------------------------------------------------------------------------------+
//

include_once(PEACHY__PRODUCTS . "peachy__Products.inc.php");

// Basic category testing
// 
// This will function will create a set of categories for two applications. It will ensure:
// - That categories are only being retrieved for the correct application
// - That categories are being saved and deleted correctly
// - That the different status constants retrieve the correct categories.
class BasicCategoryTest extends PHPUnit_TestCase {
	var $badApplicationCategory;
	var $badApplicationResult = -1;
	var $badCodeCategory;
	var $badCodeResult = -1;
	var $badStatusCategory;
	var $badStatusResult = -1;
	
	var $goodCategory;
	var $dupeCategory;
	var $dupeInsertionResult = -1;
	
	var $deletionResult = -1;
	
	var $firstApplication = 1;
	var $secondApplication = 2;
	
	var $firstAppCategory1;
	var $saveResult1 = -1;
	var $firstAppCategory2;
	var $saveResult2 = -1;
	var $firstAppCategory3;
	var $saveResult3 = -1;
	var $secondAppCategory1;
	var $saveResult4 = -1;
	var $secondAppCategory2;
	var $saveResult5 = -1;
	var $secondAppCategory3;
	var $saveResult6 = -1;
	
	var $topLevelCats;
	var $visibleCats;
	
	var $retrieveTest1;
	var $retrieveTest2;
	var $retrieveTest3;
	
	function BasicCategoryTest ($name) {
		$this->PHPUnit_TestCase($name);
	}

	function setUp() {
		// Error checking
		$this->badApplicationCategory = new Category(-1, -1, 'firstAppCategory1', 'CAT1', CATEGORY_TOPLEVEL);
		$this->badApplicationResult = SaveCategory($this->badApplicationCategory);
		$this->badCodeCategory = new Category(-1, $this->firstApplication, 'firstAppCategory1', '', CATEGORY_TOPLEVEL);
		$this->badCodeResult = SaveCategory($this->badCodeCategory);
		$this->badStatusCategory = new Category(-1, $this->firstApplication, 'firstAppCategory1', 'CAT1', -1);
		$this->badStatusResult = SaveCategory($this->badStatusCategory);
		
		$this->goodCategory = new Category(-1, $this->firstApplication, 'Good Category', 'CAT1', CATEGORY_TOPLEVEL);
		SaveCategory($this->goodCategory);
		$this->dupeCategory = new Category(-1, $this->firstApplication, 'Dupe Category', 'CAT1', CATEGORY_TOPLEVEL);
		$this->dupeInsertionResult = SaveCategory($this->dupeCategory);
		
		$this->deletionResult = DeleteCategory($this->goodCategory->strCode);
		
		$this->firstAppCategory1 = new Category(-1, $this->firstApplication, 'firstAppCategory1', 'CAT1_1', CATEGORY_TOPLEVEL);
		$this->saveResult1 = SaveCategory($this->firstAppCategory1);
		$this->firstAppCategory2 = new Category(-1, $this->firstApplication, 'firstAppCategory2', 'CAT1_2', CATEGORY_VISIBLE);
		$this->saveResult2 = SaveCategory($this->firstAppCategory2);
		$this->firstAppCategory3 = new Category(-1, $this->firstApplication, 'firstAppCategory3', 'CAT1_3', CATEGORY_VISIBLE);
		$this->saveResult3 = SaveCategory($this->firstAppCategory3);
		$this->secondAppCategory1 = new Category(-1, $this->secondApplication, 'secondAppCategory1', 'CAT2_1', CATEGORY_TOPLEVEL);
		$this->saveResult4 = SaveCategory($this->secondAppCategory1);
		$this->secondAppCategory2 = new Category(-1, $this->secondApplication, 'secondAppCategory2', 'CAT2_2', CATEGORY_VISIBLE);
		$this->saveResult5 = SaveCategory($this->secondAppCategory2);
		$this->secondAppCategory3 = new Category(-1, $this->secondApplication, 'secondAppCategory3', 'CAT2_3', CATEGORY_VISIBLE);
		$this->saveResult6 = SaveCategory($this->secondAppCategory3);
				
		$this->topLevelCats = GetCategoriesByStatus(CATEGORY_TOPLEVEL);
		$this->visibleCats = GetCategoriesByStatus(CATEGORY_VISIBLE);
		
		$this->retrieveTest1 = GetCategoryByID(1234);
		$this->retrieveTest2 = GetCategoryByCode($this->firstAppCategory2->strCode);
		$this->retrieveTest3 = GetCategoryByID($this->saveResult6);
	}

	function testBasicCategories() {
		$this->AssertTrue($this->badApplicationResult == false);
		$this->AssertTrue($this->badCodeResult == false);
		$this->AssertTrue($this->badStatusResult == false);
		$this->AssertTrue($this->dupeInsertionResult == false);
		
		$this->AssertTrue($this->deletionResult);
		
		$this->AssertTrue($this->firstAppCategory1->nStatus === CATEGORY_TOPLEVEL);
		$this->AssertEquals('firstAppCategory1', $this->firstAppCategory1->strName);
		$this->AssertTrue($this->saveResult1 != false);
		$this->AssertTrue($this->saveResult2 != false);
		$this->AssertTrue($this->saveResult3 != false);
		$this->AssertTrue($this->saveResult4 != false);
		$this->AssertTrue($this->saveResult5 != false);
		$this->AssertTrue($this->saveResult6 != false);
		
		$this->AssertEquals(1, count($this->topLevelCats));
		$this->AssertEquals(2, count($this->visibleCats));
		
		$this->AssertEquals(false, $this->retrieveTest1);
		$this->AssertEquals($this->firstAppCategory2->strName, $this->retrieveTest2->strName);
		// Not in the same application domain, y'see.
		$this->AssertEquals(false, $this->retrieveTest3);
		
		//DeleteCategory($this->firstAppCategory1->strCode);
		//DeleteCategory($this->firstAppCategory2->strCode);
		//DeleteCategory($this->firstAppCategory3->strCode);
		//DeleteCategory($this->secondAppCategory1->strCode);
		//DeleteCategory($this->secondAppCategory2->strCode);
		//DeleteCategory($this->secondAppCategory3->strCode);
	}
}

// Tests the product class on a basic level by adding it to multiple categories, adding
// a price. This is tested by saving an retrieving the same data and testing for consistency.
class BasicProductTest extends PHPUnit_TestCase {
	var $firstAppCategory1;
	var $firstAppCategory2;
	var $product1;
	var $productPrice1;
	var $saveProductResult;
	
	var $returnedProduct;
	
	function BasicProductTest ($name) {
		$this->PHPUnit_TestCase($name);
	}

	function setUp() {
		$this->firstAppCategory1 = new Category(-1, APPLICATION_ID, 'firstAppCategory4', 'CAT1_4', CATEGORY_TOPLEVEL);
		$this->firstAppCategory1->ixCategory = SaveCategory($this->firstAppCategory1);
		$this->firstAppCategory2 = new Category(-1, APPLICATION_ID, 'firstAppCategory5', 'CAT1_5', CATEGORY_VISIBLE);
		$this->firstAppCategory2->ixCategory = SaveCategory($this->firstAppCategory2);
		
		$this->product1 = new Product(-1, APPLICATION_ID, "whatever", "Product 1", time());
		
		$this->productPrice1 = new ProductPrice(-1, -1, 4.95, 3.95);
		
		$this->product1->AddCategory($this->firstAppCategory1);
		$this->product1->AddCategory($this->firstAppCategory2);
		
		$this->product1->AddPrice($this->productPrice1);
		$this->saveProductResult = SaveProduct($this->product1, 1);
		
		$this->returnedProduct = GetProductByCode("whatever", true);
	}

	function testBasicProducts() {
		$this->AssertTrue(is_numeric($this->saveProductResult));
		$this->AssertEquals(APPLICATION_ID, $this->returnedProduct->ixfApplication);
		$this->AssertEquals("Product 1", $this->returnedProduct->strTitle);
		$this->AssertEquals(2, count($this->returnedProduct->categories));
		$this->AssertTrue(false != $this->returnedProduct->productPrices);
		$this->AssertEquals('firstAppCategory4', $this->returnedProduct->categories[0]->strName);
		$this->AssertEquals(3.95, $this->returnedProduct->productPrices[0]->prcComparisonPrice);
		//DeleteProduct($this->saveProductResult);
	}
}

// Tests a combined product class, containing date effective prices and the like
class CombinedProductTest extends PHPUnit_TestCase {
	var $design;
	var $result;
	var $returnedGeneric;
	
	function CombinedProductTest ($name) {
		$this->PHPUnit_TestCase($name);
	}

	function setUp() {
		$this->design = new Generic("This is a design", "This is the extended description for the design", 3);
		$this->design->product = new Product(-1, APPLICATION_ID, str_replace(" ", "_", "This is the title"), "This is the title", time());
		$this->design->product->AddPrice(new ProductPrice(-1, -1, 199.00, 199.00));
		$this->design->product->categories = GetCategoriesByStatus(CATEGORY_TOPLEVEL);
		$this->result = SaveGeneric($this->design, 1);	
		$this->returnedGeneric = GetGeneric($this->result);
	}

	function testCombinedProducts() {
		$this->AssertEquals(true, is_numeric($this->result));
		$this->AssertFalse(false === $this->returnedGeneric);
		$this->AssertEquals(3, $this->returnedGeneric->daysETF);
		$this->AssertEquals(APPLICATION_ID, $this->returnedGeneric->product->ixfApplication);
		$this->AssertEquals("This is the title", $this->returnedGeneric->product->strTitle);
		$this->AssertEquals(2, count($this->returnedGeneric->product->categories));
		$this->AssertTrue(false != $this->returnedGeneric->product->productPrices);
		$this->AssertEquals('firstAppCategory1', $this->returnedGeneric->product->categories[0]->strName);
		$this->AssertEquals(199.00, $this->returnedGeneric->product->productPrices[0]->prcComparisonPrice);
		//$deleted = DeleteGeneric($this->returnedGeneric->product->ixProduct);
		//$this->AssertEquals(true, $deleted);
	}
}

// Creates products for different categories then attempts to retrieve them
// Returned quantities are tested against assumptions.
class ProductCategoryTest extends PHPUnit_TestCase {
	var $products;
	function ProductCategoryTest ($name) {
		$this->PHPUnit_TestCase($name);
	}
	
	function setUp() {
		$this->products = GetProductListByCategory(8, "", -1, -1);
	}

	function testProductCategories() {
		$this->AssertEquals(2, count($this->products));
	}
}

// TODO
class ProductSearchTest extends PHPUnit_TestCase {
	function ProductSearchTest ($name) {
		$this->PHPUnit_TestCase($name);
	}
	
	function setUp() {
	}

	function testSearch() {
	}
}

$suite = new PHPUnit_TestSuite();

$testBasicCategories = new BasicCategoryTest ('testBasicCategories');
$testBasicProducts = new BasicProductTest ('testBasicProducts');
$testCombinedProducts = new CombinedProductTest ('testCombinedProducts');
$testProductCategories = new ProductCategoryTest('testProductCategories');
$testSearch = new ProductSearchTest('testSearch');

$suite->addTest($testBasicCategories);
$suite->addTest($testBasicProducts);
$suite->addTest($testCombinedProducts);
$suite->addTest($testProductCategories);
$suite->addTest($testSearch);

// Run tests and print output to browser
$result = PHPUnit::run($suite);
print $result->toHTML();

?>

