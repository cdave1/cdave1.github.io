<?php
//
// +---------------------------------------------------------------------------------+
// | Peachy :: Order System :: test :: Order System Test Cases                       |
// +---------------------------------------------------------------------------------+
// | Copyright (c) 2005 Peachy Conceptual Development LTD. <http://www.peachy.co.nz> |
// +---------------------------------------------------------------------------------+
//

include_once(PEACHY__COOKIES . "peachy__Cookies.inc.php");

class BasicCookieTest extends PHPUnit_TestCase {
	var $items;
	var $clearResult;
	var $clearedItems;
	function BasicOrderSystemTest($name) {
		$this->PHPUnit_TestCase($name);
	}

	function setUp() {
		AddItemToCookie("cart", "12345", "2");
		$this->items = GetItemsInContainer("cart");
		$this->clearResult = ClearContainer("cart");
		$this->clearedItems = GetItemsInContainer("cart");
	}

	function testBasicCookies () {
		foreach ($this->items as $name => $value) {
			$this->AssertEquals("12345", $name);
			$this->AssertEquals("2", $value);
		}
		$this->AssertEquals(false, $this->clearedItems);
	}
}


$suite = new PHPUnit_TestSuite();

$testBasicCookies = new BasicCookieTest('testBasicCookies');

$suite->addTest($testBasicCookies);

// Run tests and print output to browser
$result = PHPUnit::run($suite);
print $result->toHTML();

?>