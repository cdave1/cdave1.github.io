<?php

include(LIB_UNITTEST . "PHPUnit.php");

if (isset($URI_QUERYSTRING[1])) {
	$test = $URI_QUERYSTRING[1];
}

if (isset($test)) {
	if ("kernal" == $test) {
		include("kernalTests.inc.php");
	}
}

?>