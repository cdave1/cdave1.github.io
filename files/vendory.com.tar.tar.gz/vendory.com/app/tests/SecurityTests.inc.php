<?php
//
// +---------------------------------------------------------------------------------+
// | Peachy :: Security :: Unit Tests                                                |
// +---------------------------------------------------------------------------------+
// | Copyright (c) 2005 Peachy Conceptual Development LTD. <http://www.peachy.co.nz> |
// +---------------------------------------------------------------------------------+
//

/**
 * Unit tests for the security functions.
 * 
 * @author      David Petrie <david@peachy.co.nz>
 * @copyright   Copyright &copy; 2005 Peachy Conceptual Development LTD. <http://www.peachy.co.nz>
 * @license     INTERNAL - NO DISTRIBUTION VIA INTERNET/EMAIL/FTP WITHOUT PRIOR WRITTEN PERMISSION
 * @category    Unit Tests file.
 * @package     peachy.Security
 */

include_once(PEACHY__SECURITY . "peachy__Security.inc.php");

class BasicSecurityTest extends PHPUnit_TestCase {	
	function BasicSecurityTest($name) {
		$this->PHPUnit_TestCase($name);
	}

	function SetUp() {
		
	}

	function testBasicSecurity() {
		$usStr = "<IMG SRC='   javascript:alert(\"XSS\");'>";
		$tBasicClean = time();
		
		for ($i = 0; $i < 100000; $i += 1) {
			$sStr = basicClean($usStr);
		}
		// Should take no more than 20 seconds for this test on a 1.8 GHz Celeron with 128 mB on XP).
		$this->AssertTrue(20 > (time() - $tBasicClean)));
	}
}

$suite = new PHPUnit_TestSuite();

$testBasicSecurity = new BasicSecurityTest('testBasicSecurity');

$suite->addTest($testBasicSecurity);

// Run tests and print output to browser
$result = PHPUnit::run($suite);
print $result->toHTML();

?>