<?php
//
// +---------------------------------------------------------------------------------+
// | Peachy :: Order System :: test :: Order System Test Cases                       |
// +---------------------------------------------------------------------------------+
// | Copyright (c) 2005 Peachy Conceptual Development LTD. <http://www.peachy.co.nz> |
// +---------------------------------------------------------------------------------+
//

include_once(PEACHY__ORDERSYSTEM . "peachy__OrderSystem.inc.php");

class BasicOrderSystemTest extends PHPUnit_TestCase {
	function BasicOrderSystemTest($name) {
		$this->PHPUnit_TestCase($name);
	}

	function setUp() {
	}

	function testBasicOrderSystem () {
		$this->AssertTrue(false);
	}
}

class OrderProductTest extends PHPUnit_TestCase {
	function OrderProductTest($name) {
		$this->PHPUnit_TestCase($name);
	}
	
	function setUp() {
	}
	
	function testOrderProduct () {
		$this->AssertTrue(false);
	}
}

$suite = new PHPUnit_TestSuite();

$testBasicOrderSystem = new BasicOrderSystemTest('testBasicOrderSystem');
$testOrderProduct = new OrderProductTest('testOrderProduct');

$suite->addTest($testBasicOrderSystem);
$suite->addTest($testOrderProduct);

// Run tests and print output to browser
$result = PHPUnit::run($suite);
print $result->toHTML();

?>