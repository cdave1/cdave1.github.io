<?php
// Tests the faqItem class:
// -> Inserts a faqItem into the database

include_once(PEACHY__CONTENT . "ContentClasses.inc.php");
include_once(PEACHY__CONTENT . "ContentController.inc.php");

class faqItemTest extends PHPUnit_TestCase {
	var $faqItemFresh;
	var $faqItemID;
	var $faqItemSaved;
	var $faqItemDeleted;
	
	function faqItemTest($name) {
		$this->PHPUnit_TestCase($name);
	}

	function setUp() {
		$this->faqItemFresh = new FaqItem(-1, "Test", "Test text", "category", 1, 1);
		$this->faqItemID = SaveFaqItem($this->faqItemFresh);
		$this->faqItemSaved = GetFaqItem($this->faqItemID);
		DeleteFaqItem($this->faqItemID);
		$this->faqItemDeleted = GetFaqItem($this->faqItemID);
	}
 
	function testFaqItemBasic() {
		$this->assertEquals($this->faqItemFresh->ixFaqItem, -1);
		$this->assertEquals($this->faqItemFresh->strQuestion, "Test");
		$this->assertEquals($this->faqItemFresh->txtAnswer, "Test text");
		$this->assertEquals($this->faqItemFresh->strCategory, "category");
		$this->assertEquals($this->faqItemFresh->ixlCategory, 1);
		$this->assertEquals($this->faqItemFresh->lstPrintorder, 1);
		
		$this->assertTrue($this->faqItemSaved->ixFaqItem != -1);
		$this->assertEquals($this->faqItemSaved->strQuestion, "Test");
		$this->assertEquals($this->faqItemSaved->txtAnswer, "Test text");
		$this->assertEquals($this->faqItemSaved->strCategory, "category");
		$this->assertEquals($this->faqItemSaved->ixlCategory, 1);
		$this->assertEquals($this->faqItemSaved->lstPrintorder, 1);
		
		$this->assertTrue($this->faqItemDeleted == false);
	}
}

class pageTest extends PHPUnit_TestCase {
	var $pageFresh;
	var $pageID;
	var $pageSaved;
	var $pageDeleted;
	
	function pageTest($name) {
		$this->PHPUnit_TestCase($name);
	}
	
	function setUp () {
	}

	function testPageBasic() {
		$this->assertTrue(true);
	}
}

// Create all tests
$suite = new PHPUnit_TestSuite();

$testFaqItemBasic = new faqItemTest('testFaqItemBasic');
$testPageBasic = new pageTest('testPageBasic');

$suite->addTest($testFaqItemBasic);
$suite->addTest($testPageBasic);

// Run tests and print output to browser
$result = PHPUnit::run($suite);
print $result->toHTML();

?>