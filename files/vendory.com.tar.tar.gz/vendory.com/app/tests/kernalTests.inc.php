<?php

include_once(TOTARA__KERNAL . "kernal.inc.php");

class BasicApplicationTest extends PHPUnit_TestCase {
	var $application;
	var $ixApplication;
	var $storedApp;
	var $deletionResult;
	
	function BasicApplicationTest($name) {
		$this->PHPUnit_TestCase($name);
	}
	
	function setUp() {
		$this->application = new Application(-1, "TEST", "Test Application", "vendory/test", KERNAL_APP_HOLD);
		$this->ixApplication = CreateApplication($this->application);
		$this->storedApp = GetApplicationById($this->ixApplication, false, false);
		$this->deletionResult =  DeleteApplication($this->storedApp, true);
	}

	function testApplicationBasic() {
		$this->assertTrue(is_numeric($this->ixApplication));
		$this->assertEquals("TEST", $this->storedApp->strCode);
		$this->assertEquals(KERNAL_APP_HOLD, $this->storedApp->nStatus);
		$this->assertTrue($this->deletionResult);
	}
}

class BasicGroupTest extends PHPUnit_TestCase {
	var $group;
	var $ixGroup;
	var $storedGroup;
	var $deletionResult;
	
	function BasicGroupTest($name) {
		$this->PHPUnit_TestCase($name);
	}
	
	function setUp() {
		$this->group = new Group(-1, "TESTGROUP", "test group", "group created for testing", time(), KERNAL_GRP_LIVE);
		$this->group->userOwner = new User(-1, "david@fastlogo.co.nz", "127.0.0.1", 1119182724, "", "david", 0);
		$this->ixGroup = CreateGroup($this->group);
		$this->storedGroup = GetGroupById($this->ixGroup, false, false);
		$this->deletionResult = DeleteGroup($this->storedGroup, true);
		
	}

	function testGroupBasic() {
		$this->assertTrue(is_numeric($this->ixGroup));
		$this->assertEquals("TESTGROUP", $this->storedGroup->strCode);
		$this->assertEquals(KERNAL_GRP_LIVE, $this->storedGroup->nStatus);
		$this->assertTrue($this->deletionResult);
	}
}

class ApplicationGroupTest extends PHPUnit_TestCase {
	var $application;
	var $ixApplication;

	var $group;
	var $ixGroup;
	
	var $successAppAdd;
	var $failedAppAdd;
	
	function ApplicationGroupTest($name) {
		$this->PHPUnit_TestCase($name);
	}
	
	function setUp() {
	}

	// - Adding an application to a group
	// - Creating a group with applications added to it
	// - Updating a group's applications
	// - Retrieving a group's applications
	// - Retrieving an application's groups
	// - Deleting a group (with no purge)
	// - Deleted groups do not appear in application listings.
	// - Deleting a group (with purge) also removes a group/application connections
	function testApplicationGroup() {
		$this->application = new Application(-1, "TEST", "Test Application", "vendory/test", KERNAL_APP_HOLD);
		$this->ixApplication = CreateApplication($this->application);
		$this->storedApp = GetApplicationById($this->ixApplication, false, false);
		
		$this->group = new Group(-1, "TESTGROUP", "test group", "group created for testing", time(), KERNAL_GRP_LIVE);
		$this->group->userOwner = new User(-1, "david@fastlogo.co.nz", "127.0.0.1", 1119182724, "", "david", 0);
		
		$this->group->AddApplication($this->storedApp);
		$this->group->AddApplication($this->storedApp); // this one should not work
		
		$this->assertEquals(1, count($this->group->applications));
		
		$this->ixGroup = CreateGroup($this->group);
		$this->storedGroup = GetGroupById($this->ixGroup, true, false);
		
		$this->assertEquals(1, count($this->storedGroup->applications));
		
		$this->application2 = new Application(-1, "TEST2", "Test Application 2", "vendory/test2", KERNAL_APP_HOLD);
		$this->application2->ixApplication = CreateApplication($this->application2);
		$this->storedGroup->AddApplication($this->application2);
		
		UpdateGroup($this->storedGroup);
		
		$this->storedGroup2 = GetGroupById($this->ixGroup, true, false);
		$this->assertEquals(2, count($this->storedGroup2->applications));
		
		$this->app2 = GetApplicationByID($this->ixApplication, true, false);
		$this->app3 = GetApplicationByID($this->application2->ixApplication, true, false);
		
		$this->assertEquals(1, count($this->app2->groups));
		$this->assertEquals(1, count($this->app3->groups));
	}
}

class BasicUserTest extends PHPUnit_TestCase {
	var $goodUser;
	var $proposedUserPassword = "cmdmc";
	var $validationResult;
	var $ixGoodUser = -1;
	var $saveUserTwice = 99999;
	var $forgotPasswordResult = "";
	var $retrievedUser;
	var $badRetrievedUser;
	var $badUserEmail;
	var $badUserPassword;
	
	function BasicUserTest($name) {
		$this->PHPUnit_TestCase($name);
	}
	
	function setUp() {
		$this->application = new Application(-1, "TEST", "Test Application", "vendory/test", KERNAL_APP_HOLD);
		$this->ixApplication = CreateApplication($this->application);
		$this->storedApp = GetApplicationById($this->ixApplication, false, false);
		
		$this->group = new Group(-1, "TESTGROUP", "test group", "group created for testing", time(), KERNAL_GRP_LIVE);
		$this->group->userOwner = new User(-1, "david@peachy.co.nz", "127.0.0.1", time(), "", "david", 0);
		$this->group->AddApplication($this->storedApp);
		$this->group->ixGroup = CreateGroup($this->group);
		
		$this->goodUser = new User(-1, "david@fastlogo.co.nz", "127.0.0.1", time(), "", "david", 0);
		$this->goodUser->createSecurityObject($this->proposedUserPassword);
		$this->validationResult = ValidateNewUser($this->goodUser, $this->proposedUserPassword, $this->group->ixGroup);
		$this->goodUser->AddGroup($this->group);
		$this->ixGoodUser = SaveUser($this->goodUser, $this->group->ixGroup);
		
		$this->forgotPasswordResult = RetrievePassword("david@fastlogo.co.nz");
		$this->saveUserTwice = SaveUser($this->goodUser, $this->group->ixGroup);
		$this->retrievedUser = GetUserByID($this->ixGoodUser, true);
		DeleteUser($this->ixGoodUser);
		$this->badRetrievedUser = GetUserByID($this->ixGoodUser, true);
	}

	function testUserBasic() {
		//$this->assertEquals("74cb957550832eebd1efda72db1b367139125552", $this->goodUser->checksum1);
		//$this->assertEquals("74cb957550832eebd1efda72db1b367139125552", $this->goodUser->userSecurity->checksum1);
		$this->assertEquals(true, $this->validationResult);
		$this->assertTrue($this->ixGoodUser > 0, "Good user to be greater than 0");
		$this->assertEquals($this->proposedUserPassword, trim($this->forgotPasswordResult));
		$this->assertTrue($this->saveUserTwice === false, "Save user twice fails:");
		$this->assertEquals("david@fastlogo.co.nz", $this->retrievedUser->email);
		//$this->assertEquals("74cb957550832eebd1efda72db1b367139125552", $this->retrievedUser->checksum1);
		$this->assertTrue($this->badRetrievedUser === false, "Bad retrieved user is false:");
	}
}

class LoginUserTest extends PHPUnit_TestCase {
	var $goodUser;
	var $proposedUserPassword = "cmdmc";
	var $submittedEmail = "david@fastlogo.co.nz";
	var $submittedPassword = 'cmdmc';
	var $authenticationResult1;
	var $authenticationResult2;
	var $authenticationResult3;
	var $authenticationResult4;
	var $authenticationResult5;
	var $authenticationResult6;
	
	var $unexistingSubmittedEmail = "a@b.c";
	var $unexistingSubmittedPassword = 'NOPASSWORD';
	
	var $badSubmittedEmail = "dav id_pea'chy.co.nz";
	var $badSubmittedPassword = '_______??cmdmc';
	
	
	function LoginUserTest($name) {
		$this->PHPUnit_TestCase($name);
	}
	
	function setUp() {
		$this->application = new Application(-1, "TEST", "Test Application", "vendory/test", KERNAL_APP_HOLD);
		$this->ixApplication = CreateApplication($this->application);
		$this->storedApp = GetApplicationById($this->ixApplication, false, false);
		
		$this->group = new Group(-1, "TESTGROUP", "test group", "group created for testing", time(), KERNAL_GRP_LIVE);
		$this->group->userOwner = new User(-1, "david@peachy.co.nz", "127.0.0.1", time(), "", "david", 0);
		$this->group->AddApplication($this->storedApp);
		$this->group->ixGroup = CreateGroup($this->group);
		
		$this->goodUser = new User(-1, "david@fastlogo.co.nz", "127.0.0.1", time(), "", "david", 0);
		$this->goodUser->createSecurityObject($this->proposedUserPassword);
		$this->validationResult = ValidateNewUser($this->goodUser, $this->proposedUserPassword, $this->group->ixGroup);
		$this->goodUser->AddGroup($this->group);
		$this->ixGoodUser = SaveUser($this->goodUser, $this->group->ixGroup);
		
		$this->authenticationResult1 = AuthenticateUser($this->submittedEmail, $this->submittedPassword, $this->group->ixGroup);
		$this->authenticationResult2 = AuthenticateUser($this->submittedEmail, $this->unexistingSubmittedPassword, $this->group->ixGroup);
		$this->authenticationResult3 = AuthenticateUser($this->unexistingSubmittedEmail, $this->submittedPassword, $this->group->ixGroup);
		$this->authenticationResult4 = AuthenticateUser($this->badSubmittedEmail, $this->submittedPassword, $this->group->ixGroup);
		$this->authenticationResult5 = AuthenticateUser($this->submittedEmail, $this->badSubmittedPassword, $this->group->ixGroup);
		$this->authenticationResult6 = AuthenticateUser("", "", $this->group->ixGroup);
		//DeleteUser($this->ixGoodUser);
	}
	
	function testUserLogin() {
		$this->assertEquals($this->submittedEmail, $this->authenticationResult1->email, "1");
		$this->assertEquals(NO_USER_FOUND, $this->authenticationResult2, "2");
		$this->assertEquals(NO_USER_FOUND, $this->authenticationResult3, "3");
		$this->assertEquals(INVALID_EMAIL, $this->authenticationResult4, "4");
		$this->assertEquals(INVALID_PASSWORD, $this->authenticationResult5, "5");
		$this->assertEquals(NO_EMAIL_ADDRESS, $this->authenticationResult6, "6");
	}
}

class SecurityTest extends PHPUnit_TestCase {
	function SecurityTest($name) {
		$this->PHPUnit_TestCase($name);
	}
	
	function setUp() {
		
	}

	function testKernalSecurity() {
		$this->a1 = AuthenticateUser("0x22--@email.com", "password", "TESTGROUP");
		$this->assertFalse($this->a1, "Sql injection comments attack returns false");
	}
}

$suite = new PHPUnit_TestSuite();

$testApplicationBasic = new BasicApplicationTest('testApplicationBasic');
$testGroupBasic = new BasicGroupTest('testGroupBasic');
$testApplicationGroup = new ApplicationGroupTest('testApplicationGroup');
$testUserBasic = new BasicUserTest('testUserBasic');
$testUserLogin = new LoginUserTest('testUserLogin');
$testKernalSecurity = new SecurityTest('testKernalSecurity');

//$suite->addTest($testApplicationBasic);
//$suite->addTest($testGroupBasic);
//$suite->addTest($testApplicationGroup);
//$suite->addTest($testUserBasic);
//$suite->addTest($testUserLogin);
$suite->addTest($testKernalSecurity);

// Run tests and print output to browser
$result = PHPUnit::run($suite);
print $result->toHTML();

?>