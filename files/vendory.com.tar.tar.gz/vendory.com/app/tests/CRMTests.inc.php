<?php

include_once(PEACHY__CRM . "CRMClasses.inc.php");
include_once(PEACHY__CRM . "CRMControllers.inc.php");

class BasicMessageTest extends PHPUnit_TestCase {
	var $messageFresh;
	var $messageID;
	var $messageSaved;
	var $messageDeleted;
	
	function messageTest($name) {
		$this->PHPUnit_TestCase($name);
	}

	function setUp() {
		$this->messageFresh = new Message(-1, time(), "david@peachy.co.nz", "David", "david@peachy.co.nz", "This is a test", "This is the main message", 1);
		$this->messageID = SaveMessage($this->messageFresh);
		$this->messageSaved = GetMessage($this->messageID);
		DeleteMessage($this->messageID);
		$this->messageDeleted = GetMessage($this->messageID);
	}
 
	function testMessageBasic() {
		$this->assertEquals($this->messageFresh->ixMessage, -1);
		$this->assertEquals($this->messageFresh->strSenderEmail, "david@peachy.co.nz");
		$this->assertEquals($this->messageFresh->strSenderName, "David");
		$this->assertEquals($this->messageFresh->strRecipientEmail, "david@peachy.co.nz");
		$this->assertEquals($this->messageFresh->txtSubject, "This is a test");
		$this->assertEquals($this->messageFresh->txtMessage, "This is the main message");
		$this->assertEquals($this->messageFresh->nStatus, 1);
		
		$this->assertTrue($this->messageSaved->ixMessage != -1);
		$this->assertEquals($this->messageSaved->strSenderEmail, "david@peachy.co.nz");
		$this->assertEquals($this->messageSaved->strSenderName, "David");
		$this->assertEquals($this->messageSaved->strRecipientEmail, "david@peachy.co.nz");
		$this->assertEquals($this->messageSaved->txtSubject, "This is a test");
		$this->assertEquals($this->messageSaved->txtMessage, "This is the main message");
		$this->assertEquals($this->messageSaved->nStatus, 1);
		
		$this->assertTrue($this->messageDeleted == false);
	}
}

class AdvancedMessageTest extends PHPUnit_TestCase {
	var $messageFresh1;
	var $messageFresh2;
	var $messages;
	var $deletedMessages;
	
	function messageTest($name) {
		$this->PHPUnit_TestCase($name);
	}

	function setUp() {
		$this->messageFresh1 = new Message(-1, time(), "david@peachy.co.nz", "David", "david@peachy.co.nz", "This is a test", "This is the main message", 1);
		SaveMessage($this->messageFresh1);
		$this->messageFresh2 = new Message(-1, time(), "david@peachy.co.nz", "David", "david@peachy.co.nz", "This is a test", "This is the main message", 1);
		SaveMessage($this->messageFresh2);
		
		$this->messages = GetMessages();
		
		foreach($this->messages as $message) {
			DeleteMessage($message->ixMessage);
		}
		
		$this->deletedMessages = GetMessages();
	}
 
	function testMessageAdvanced() {
		$this->assertEquals(2, count($this->messages));
		$this->assertEquals(false, $this->deletedMessages);
	}
}

// Create all tests
$suite = new PHPUnit_TestSuite();

$testMessageBasic = new BasicMessageTest('testMessageBasic');
$testMessageAdvanced = new AdvancedMessageTest('testMessageAdvanced');

$suite->addTest($testMessageBasic);
$suite->addTest($testMessageAdvanced);

// Run tests and print output to browser
$result = PHPUnit::run($suite);
print $result->toHTML();

?>