<div id="footerMenu">
<a href="/contact">Contact Us</a>

<br />
Copyright &copy; 2005 Peachy Conceptual Development Ltd.
</div>