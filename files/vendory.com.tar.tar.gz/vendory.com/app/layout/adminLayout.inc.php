<?

include(APP_LAYOUT . "xhtmlHeader.inc.php");

?>

<body id="info">

<div id="container">

<!-- HEADER -->

<?

include(APP_LAYOUT . "headerMenu.inc.php");

?>

<!-- END HEADER -->



<!-- MAIN CONTENT AREA START -->

<div id="adminContentArea">

<?

include($mainInclude);

?>

</div>

</div>

<!-- MAIN CONTENT AREA END -->

</body>
</html>