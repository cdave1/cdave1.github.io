<div id="mainHeader">
<div class="logo">vendory.com</div>

<div class="menu">
<ul>
<?php if (loggedIn(APP_ADMIN_GROUP) || loggedIn(APP_NORMAL_USERS)) { 
	$currUser = GetCurrentUser();
	printf("<li class='naked'>Logged in as <b>%s</b></li>", $currUser->usrScreenName);
?>
	<li><a href="/admin/home">Account Home</a></li>
	<li><a href="/admin/help">Help</a></li>
	<li><a href="/signout">Sign Out</a></li>
<? } else { ?>
	<li><a href="/login">Sign In</a></li>
<?php } ?>
</ul>
</div>
<?php if (loggedIn(APP_ADMIN_GROUP) || loggedIn(APP_NORMAL_USERS)) { ?>
	<div class="appMenu">
	<small><b>
<?php 
	$currUser = GetCurrentUser();
	$allowedGroup = GetGroupByCode(APP_ADMIN_GROUP, false, true);
	if ($allowedGroup->ContainsUser($currUser->ixUser)) { ?>
		<a href='/admin/apps/list'>All Applications...</a>&nbsp;&bull;&nbsp;
		<a href='/admin/apps/create'>New Application</a>
	<?php } else { ?>
		<a href='/admin/apps/list'>All Applications...</a>
	<?php } ?>
	</b></small>

	<form method="POST" action="/admin/apps/change">
	<b>Current Application:</b>&nbsp;
	<select name="strAppCode">
	<?php 
	
	$allApplications = GetApplicationsForUser($currUser->ixUser);
	if (0 < count($allApplications)) {
		foreach($allApplications as $app) {
			printf("<option value='%s'", $app->strCode);
			if (GetAdminApplication() == $app->strCode) {
				print " selected";
			}
			print ">" . $app->strTitle . " (" . $app->urlRoot . ")</option>";
		}
	}
	?>
	</select>
	<input type="submit" value="go">
	</form>

<?php } ?>
</div>
</div>

