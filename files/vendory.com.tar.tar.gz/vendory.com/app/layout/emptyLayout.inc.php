<?

include(APP_LAYOUT . "xhtmlHeader.inc.php");

?>
<?

include($main_include);

?>