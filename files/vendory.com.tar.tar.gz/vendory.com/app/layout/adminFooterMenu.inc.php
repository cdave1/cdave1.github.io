<div id="footerMenu">
Copyright &copy; 2005 Peachy Conceptual Development Ltd.
</div>