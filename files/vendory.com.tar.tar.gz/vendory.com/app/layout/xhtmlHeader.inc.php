<!DOCTYPE html 
    PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title><?php echo SITE_TITLE . " : " .  $title; ?></title>

<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="robots" content="all" />
<script type="text/javascript" src="/js/interface.js"></script>
<script type="text/javascript" src="/js/xmlhttp.js"></script>
<link rel="stylesheet" href="/stylesheet/webStyles.css" type="text/css" />
</head>