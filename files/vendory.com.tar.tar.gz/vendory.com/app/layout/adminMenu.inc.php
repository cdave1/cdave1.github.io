<?php

class Plugin {
	var $strCode = "";
	var $strAccess = "";
	
	function Plugin ($strCode, $strAccess) {
		$this->strCode = $strCode;
		$this->strAccess = $strAccess;
	}
}

$plugins = array();

$plugins[0] = new Plugin("apps","Home");
$plugins[1] = new Plugin("groups","Groups&nbsp;&amp;&nbsp;Users");
$plugins[2] = new Plugin("cms","Content");
$plugins[3] = new Plugin("mhorders","Orders");
$plugins[4] = new Plugin("mhproducts","Products");
$plugins[5] = new Plugin("mhmarketing","Marketing");
$plugins[6] = new Plugin("crm","Messages");
$plugins[7] = new Plugin("bugs","Bug/Issues");

define("TAB_ADMIN_ACTIVE", "<td class='activeTab'><div class='active1'> <div class='active2'> <div class='active3'> </div> </div> </div> <div class='activeTabText'>");
define("TAB_ADMIN_INACTIVE", "<td class='inactiveTab'><div class='inactive1'> <div class='inactive2'> <div class='inactive3'> </div> </div> </div> <div class='inactiveTabText'>");
define("TAB_ADMIN_GAP", "</div></td><td>&nbsp;</td>");

?>
<table border="0" cellpadding="0" cellspacing="0" id="adminMenu">
<tr>
<td>&nbsp;</td>
<?
foreach($plugins as $plugin) {
	if (isset($URI_QUERYSTRING[1]) && $URI_QUERYSTRING[1] == $plugin->strCode) 
	{ 
		echo TAB_ADMIN_ACTIVE;
	} 
	else 
	{ 
		echo TAB_ADMIN_INACTIVE;
	}
	printf("<a href='/admin/%s'>%s</a>",$plugin->strCode,$plugin->strAccess);
	echo TAB_ADMIN_GAP;
}
?>
</tr>
</table>