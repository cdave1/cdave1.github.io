<?

include(APP_LAYOUT . "xhtmlHeader.inc.php");

?>

<body onLoad="window.print()">

<div id="printContainer">

<!-- MAIN CONTENT AREA START -->

<div class="printContentArea">

<?

include($mainInclude);

?>

</div>

<!-- MAIN CONTENT AREA END -->

</div>

</body>
</html>