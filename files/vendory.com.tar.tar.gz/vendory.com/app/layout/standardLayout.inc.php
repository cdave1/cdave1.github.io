<?

include(APP_LAYOUT . "xhtmlHeader.inc.php");

?>

<body>

<div id="container">

<!-- HEADER -->

<?

include(APP_LAYOUT . "headerMenu.inc.php");

?>

<!-- END HEADER -->



<!-- MAIN CONTENT AREA START -->

<div class="contentArea">

<?

include($main_include);

?>

</div>

<!-- MAIN CONTENT AREA END -->

<!-- START FOOTER -->

<?php

include(APP_LAYOUT . "footerMenu.inc.php");

?>

<!-- START FOOTER -->

</div>

</body>
</html>