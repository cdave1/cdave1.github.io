<?php

// TOTARA database connectivity
// Kernal
function GetKernalDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("", "", "", "vendoryKernal");
}

// TOTARA database connectivity
// Core
function GetCoreDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("", "", "", "vendoryCore");
}

// Other modules
// Commerce
function GetCommerceDB() {
	return new MySQLDB("", "", "", "vendoryCommerce");
}

// Contacts
function GetContactsDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("", "", "", "vendoryContacts");
}

// Content
function GetContentDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("", "", "", "vendoryContent");
}

// CRM
function GetCRMDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("", "", "", "vendoryCRM");
}

// Location
function GetLocationDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("", "", "", "vendoryLocation");
}

// Questionnaire
function GetQuestionnaireDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("", "", "", "vendoryQuestionnaire");
}

// Social Networking
function GetSNDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("", "", "", "vendorySN");
}

// HACK HACK HACK - this is a temporary code fix
// Moviehouse
function GetMoviehouseDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("", "", "", "modivio");
}

?>