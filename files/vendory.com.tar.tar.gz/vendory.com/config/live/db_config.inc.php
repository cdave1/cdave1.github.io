<?php

// TOTARA database connectivity
// Kernal
function GetKernalDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("localhost", "t_kernalAdmin", "k9defhx7ac", "totaraKernal");
}
// Core
function GetTagDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("localhost", "twc_admin", "73ankzG4", "twc_db");
}
// Other modules
// Commerce
function GetCommerceDB() {
	return new MySQLDB("localhost", "totara_admin", "s65bbe0zk", "totaraCommerce");
}

// Contacts
function GetContactsDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("localhost", "totara_admin", "s65bbe0zk", "totaraContacts");
}

// Content
function GetContentDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("localhost", "t_contentAdmin", "jjj65lmze", "totaraContent");
}

// CRM
function GetCRMDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("localhost", "t_crmAdmin", "s65bbe0zk", "totaraCRM");
}

// Location
function GetLocationDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("localhost", "totara_admin", "s65bbe0zk", "totaraLocation");
}

// Questionnaire
function GetQuestionnaireDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("localhost", "totara_admin", "s65bbe0zk", "totaraQuestionnaire");
}

// Social Networking
function GetSNDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("localhost", "totara_admin", "s65bbe0zk", "totaraSN");
}

// HACK HACK HACK - this is a temporary code fix
// Moviehouse
function GetMoviehouseDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("127.0.0.1", "modivio_admin", "s23mVn9", "modivio");
}

?>