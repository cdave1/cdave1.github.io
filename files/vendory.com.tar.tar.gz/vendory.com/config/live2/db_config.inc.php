<?php

// TOTARA database connectivity
// Kernal
function GetKernalDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("127.0.0.1", "mhDBUser", "xxcL51hab", "mhKernal");
}

// TOTARA database connectivity
// Core
function GetCoreDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("127.0.0.1", "mhDBUser", "xxcL51hab", "mhCore");
}

// Other modules
// Commerce
function GetCommerceDB() {
	return new MySQLDB("127.0.0.1", "mhDBUser", "xxcL51hab", "mhCommerce");
}

// Contacts
function GetContactsDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("127.0.0.1", "mhDBUser", "xxcL51hab", "mhContacts");
}

// Content
function GetContentDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("127.0.0.1", "mhDBUser", "xxcL51hab", "mhContent");
}

// CRM
function GetCRMDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("127.0.0.1", "mhDBUser", "xxcL51hab", "mhCRM");
}

// Location
function GetLocationDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("127.0.0.1", "mhDBUser", "xxcL51hab", "mhLocation");
}

// HACK HACK HACK - this is a temporary code fix
// Moviehouse
function GetMoviehouseDB() {
	// Format: host, user, password, dbname
	return new MySQLDB("127.0.0.1", "mhDBUser", "xxcL51hab", "mhModivio");
}

?>