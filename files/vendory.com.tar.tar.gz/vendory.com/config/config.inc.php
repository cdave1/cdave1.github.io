<?php

session_start();

header("Cache-control: private"); 
header('P3P: CP="IDC DSP COR CURa ADMa OUR IND PHY ONL COM STA"'); 

// Public HTTP Constants
define ('HTTP_ROOT', "http://vendorycom/");
define ('HTTPS_ROOT', "http://vendorycom/");

// Peachy libraries
define ('LIBRARIES', "C:\\web\\totara\\_libs2\\");
include (LIBRARIES . "libs.inc.php");

// DB Configuration include
include ("db_config.inc.php");

// Application Files
define ('FILEPATH_ROOT', "C:\\web\\vendory\\vendory.com\\");
define ('CONFIG_PATH', FILEPATH_ROOT . "config\\");
define ('APP_CONTENT', FILEPATH_ROOT . "app\\content\\");
define ('APP_LAYOUT', FILEPATH_ROOT . "app\\layout\\");
define ('APP_VIEWS', FILEPATH_ROOT . "app\\views\\");
define ('APP_TEST', FILEPATH_ROOT . "app\\tests\\");

// Constants
define("SITE_TITLE", "Vendory");
define("APPLICATION_CODE", "TEST");
define("APP_ADMIN_GROUP", "VENDORYADMIN");
define("APP_NORMAL_USERS", "VENDORYCUSTOMER");

// Testsite
$testsite = true;

// Layout constants
define("HOME_LAYOUT", APP_LAYOUT . "standardLayout.inc.php");
define("STANDARD_LAYOUT", APP_LAYOUT . "standardLayout.inc.php");
define("PAGE_LAYOUT", APP_LAYOUT . "standardLayout.inc.php");
define("ADMIN_LAYOUT", APP_LAYOUT . "adminLayout.inc.php");
define("EMPTY_LAYOUT", APP_LAYOUT . "emptyLayout.inc.php");
define("PRINT_LAYOUT", APP_LAYOUT . "printLayout.inc.php");
define("RSS_LAYOUT", APP_LAYOUT . "rssLayout.inc.php");

// Application Constants
define("SIGNOUT_LANDING_PAGE", "/index");
define("BUSINESS_NAME", "Vendory");
define("EMAIL_ROOT", "vendory.com");
define('IMAGE_ARROW', "&nbsp;&nbsp;&nbsp;<img src=\"/images/img_arrow.gif\" border=\"0\">&nbsp;");

define("UNIVERSAL_ENCRYPTION_KEY", "280eade57bb911b55f10b7eeee3b50");

// AMAZON CONSTANTS
define('ASSOCIATE_ID', 'bandyboo-20');
define('DEVELOPER_TOKEN','1H36R44GHX5BCHSCJ282');

include(TOTARA__KERNAL . "kernal.inc.php");
include(TOTARA__CRM . "totara__CRM.inc.php");
include(TOTARA__LAYOUT . "drawingFunctions.inc.php");
include(TOTARA__UTILITIES . "utilities.inc.php");

?>