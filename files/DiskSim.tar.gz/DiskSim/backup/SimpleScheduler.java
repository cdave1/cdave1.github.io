// Copyright David Petrie 2008
//
// A very simple scheduler, not required for the assignment.
//
// Much of the source code for this example was given to us during a tutorial.
import java.util.*;


public class SimpleScheduler implements DiskScheduler {
	private LinkedList<DiskRequest> queue;
	private DiskRequest currentRequest;



	public SimpleScheduler() 
	{
		queue = new LinkedList();
		currentRequest = null;
	}



	// Publish a request to driver.
	// Wait for request to be completed.
	// Return the result of the request.
	//
	// Monitor equivalent: a waitC statement
	public Object makeRequest(DiskRequest req) {
		synchronized(this) {
			queue.add(req);
			if (queue.size() == 1)
				this.notify();
		}
		req.waitUntilServiced();
		return req.getResult();
	}



	// Wait until there is another request.
	// Select a request and return it
	//
	// Monitor equivalent: signalC statement
	public DiskRequest getNextRequest() {
		if (queue.size() > 0) {
			currentRequest = queue.removeFirst();
		} else {
			try {
				while (queue.size() == 0) this.wait();
				currentRequest = queue.removeFirst();
			} catch (InterruptedException e) {
				System.out.println("Server interrupted during wait.");
				return null;
			}
		}
		return currentRequest;
	}



	public int getDistanceTravelled() {
		return 0;
	}



	// Pass result to requesting process.
	public void finishedRequest(Object response) {
		currentRequest.setResponseAndNotify(response);
		currentRequest = null;
	}
}
