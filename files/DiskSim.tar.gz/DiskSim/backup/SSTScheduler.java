// Copyright David Petrie 2008
//
// Implementation of a SST scheduler.
//
// Project notes:
//
// In this policy, the request that wants to access the cylinder closest to the
// one at which the read/write heads are currently positioned is always scheduled 
// first. This policy minimizes seek time. However, SST will starve a request to 
// access a cylinder far from the current head position, if there is a steady 
// stream of requests for accesses close to the current head position. Thus there 
// is no bound on how long a request may be delayed.
import java.util.*;

public class SSTScheduler implements DiskScheduler {
	private LinkedList<DiskRequest> queue;
	private DiskRequest currentRequest;
	private ArrayList distances = new ArrayList();
	private int distanceTravelled = 0;
	private int totalRequests = 0;
	private int currentCyl = 0;

	public SSTScheduler() 
	{
		queue = new LinkedList();
		currentRequest = null;
	}



	// Publish a request to driver.
	// Wait for request to be completed.
	// Return the result of the request.
	//
	// Monitor equivalent: a waitC statement
	public Object makeRequest(DiskRequest req) {
		totalRequests++;
		synchronized(this) {
			queue.add(req);
			if (queue.size() == 1)
				this.notify();
		}
		req.waitUntilServiced();
		return req.getResult();
	}



	// Wait until there is another request.
	// Select a request and return it
	//
	// Needs to get the request on the queue NEAREST the
	// current request.
	public DiskRequest getNextRequest() {
		if (queue.size() > 0) {
			currentRequest = getNearestRequest();
		} else {
			try {
				while (queue.size() == 0) this.wait();
				currentRequest = queue.removeFirst();
			} catch (InterruptedException e) {
				System.out.println("Server interrupted during wait.");
				return null;
			}
		}
		return currentRequest;
	}



	// Gets the nearest request to current request. Just looks for the node
	// that is the smallent number of units away from the current.
	private DiskRequest getNearestRequest() {
		int minDist = Integer.MAX_VALUE;
		DiskRequest ret = null;
		for (DiskRequest req : queue) {
			int tmpDst = Math.abs(req.getCyl() - currentCyl);
			if (tmpDst < minDist) {
				minDist = tmpDst;
				ret = req;
			}
		}
		distanceTravelled += minDist;
		distances.add(minDist);
		queue.remove(ret);
		currentCyl = ret.getCyl();
		return ret;
	}



	// Pass result to requesting process.
	public void finishedRequest(Object response) {
		currentRequest.setResponseAndNotify(response);
		currentRequest = null;
	}


	
	public int getDistanceTravelled() {
		return distanceTravelled;
	}



	public int getTotalRequests() {
		return totalRequests;
	}


	
	public ArrayList getStatsArray() {
		Collections.sort(distances);
		return distances;
	}



	public void printStats(boolean isVerbose) {
		if (isVerbose) {
			System.out.println("SST:");
			System.out.println("Scheduler travelled " + getDistanceTravelled());
			System.out.println("Total requests: " + getTotalRequests());
			System.out.println("Average distance: " + getDistanceTravelled() / getTotalRequests());
			System.out.println("Max distance: " + getStatsArray().get(getStatsArray().size() -1));
		} else {
			System.out.print("SST,");
			System.out.print(getDistanceTravelled() + ", ");
			System.out.print(getTotalRequests() + ", ");
			System.out.print(getDistanceTravelled() / getTotalRequests() + ", ");
			System.out.println(getStatsArray().get(getStatsArray().size() -1));
		}
	}
}
