// Copyright David Petrie 2008
//
// Disk Request...
//
// Notes:
//
// - You should use the following class and define subclasses of it for your own implementation.
// - The parameter to the constructor is the address of the cylinder to be accessed (we ignore other possible
//   parameters for this project.

public class DiskRequest {
	Object response;
	int cyl;

	public DiskRequest(int c) { 
		cyl = c;
		response = null;
	}

	synchronized void waitUntilServiced() {
		try {
			while (response == null) this.wait();
		} catch(InterruptedException e) {
			System.out.println("Client interrupted during wait.");
		}
	}

	Object getResult() {
		return response;
	}

	synchronized void setResponseAndNotify(Object resp) {
		response = resp;
		this.notify();
	}

	public int getCyl() { return cyl; }
}
