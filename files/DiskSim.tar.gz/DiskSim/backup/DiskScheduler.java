// Copyright David Petrie 2008
//
// Disk Scheduler interface
import java.util.*;

public interface DiskScheduler {

	public Object makeRequest(DiskRequest req);
		// Publish a request to driver.
		// Wait for request to be completed.
		// Return the result of the request.

	public DiskRequest getNextRequest();
		// Wait until there is another request.
		// Select a request and return it

	public void finishedRequest(Object response);
		// Pass result to requesting process.
	
	public int getDistanceTravelled();


	public int getTotalRequests();


	public ArrayList getStatsArray();


	public void printStats(boolean isVerbose);
}
