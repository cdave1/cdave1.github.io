// Copyright David Petrie 2008
//
// Driver for different implementations of DiskScheduler
//
// Instances of the Disk Scheduler interface will be used by several threads. There will be a server
// thread that does the following (not in any particular order):
// - Repeatedly calls getNextRequest() to obtain a new request
// - Once the request has been serviced calls finishedRequest(response) with the response from the 
//   request.
// 
// Also, there will be several client threads that repeatedly call makeRequest(req) to request disk
// access.
//
// The driver will test the properties of the different scheduling policies, so it will contain java
// threads that similate the server and client threads described above.
//
// Threads executing the makeRequest method must publish the request for the server to later process,
// and then wait until the processing is complete. 
//
// WHen the server thread invokes getNextRequest, it must:
// - Wait until a request is available
// - Choose a request based on the scheduling policy
// - Return the request.
// - Finally, the finishedRequest method must comminicate the reuslt of hte latest request to the thread
// that made it.
import java.util.*;
import java.lang.Math;
import ml.options.*;
import static ml.options.Options.*;

public class Driver {
	private static boolean verbosity = true;
	private static int numClients = 20;
	private static int numServers = 2;
	private static int maxClientRequests = 10;
	private static int numCylinders = 1000;



	// Collect the options from the command line, and then create
	// a set of clients and servers, and get them started.
	public static void main(String[] args) {
		DiskScheduler scheduler = new CSCANScheduler();

		Options opt = new Options(args, 0);

		opt.getSet().addOption("d", Multiplicity.ZERO_OR_ONE);
		opt.getSet().addOption("e", Multiplicity.ZERO_OR_ONE);
		opt.getSet().addOption("t", Separator.BLANK, Multiplicity.ZERO_OR_ONE);
		opt.getSet().addOption("c", Separator.BLANK, Multiplicity.ZERO_OR_ONE);
		opt.getSet().addOption("s", Separator.BLANK, Multiplicity.ZERO_OR_ONE);
		opt.getSet().addOption("r", Separator.BLANK, Multiplicity.ZERO_OR_ONE);
		opt.getSet().addOption("y", Separator.BLANK, Multiplicity.ZERO_OR_ONE);
		if (!opt.check(true, false)) printUsage();

		if (opt.getSet().isSet("e")) verbosity = false;

		if (opt.getSet().isSet("t")) {
			String res = opt.getSet().getOption("t").getResultValue(0);
			if (res.equals("s")) scheduler = new SSTScheduler();
		}
		if (opt.getSet().isSet("c")) {
			String res = opt.getSet().getOption("c").getResultValue(0);
			numClients = Math.max(0, Integer.parseInt(res));
		}
		if (opt.getSet().isSet("s")) {
			String res = opt.getSet().getOption("s").getResultValue(0);
			numServers = Math.max(0, Integer.parseInt(res));
		}
		if (opt.getSet().isSet("r")) {
			String res = opt.getSet().getOption("r").getResultValue(0);
			maxClientRequests = Math.max(0, Integer.parseInt(res));
		}
		if (opt.getSet().isSet("y")) {
			String res = opt.getSet().getOption("y").getResultValue(0);
			numCylinders = Math.max(0, Integer.parseInt(res));
		}

		Client[] clients = new Client[numClients];
		Server[] servers = new Server[numServers];

		for (int i = 0; i < numClients; i++) {
			clients[i] = new Client(scheduler, i * 1000, maxClientRequests, numCylinders);
			clients[i].start();
		}

		for (int i = 0; i < numServers; i++) {
			servers[i] = new Server(scheduler);
			servers[i].start();
		}

		// run servers until all clients have finished.
		while(clientsAlive(clients));
		endServers(servers);

		scheduler.printStats(verbosity);
		System.exit(0);
		
	}



	// True if at least one client thread still alive, false otherwise.
	private static boolean clientsAlive(Client[] clients) {
		for (int i = 0; i < clients.length; i++) {
			if (clients[i].isAlive()) return true;
		}
		return false;
	}


	
	// stops servers from looping endlessly.
	private static void endServers(Server[] servers) {
		for (int i = 0; i < servers.length; i++)
			servers[i].clientsAlive = false;		
	}



	private static void printUsage() {
		System.out.println("USAGE: java Driver [OPTIONS] ");
		System.out.println("Try 'java Driver -d' to use default values");
		System.out.println();
		System.out.println("Options are:");
		System.out.println("\t-d\t\tUse all default values");
		System.out.println("\t-e\t\tExperiments mode - data lists only.");
		System.out.println("\t-t={c,s}\tScheduler type. 'c' for CSCAN, 's' for SST.");
		System.out.println("\t-c={n}\t\tNumber of clients. If unspecified, default will be 20.");
		System.out.println("\t-s={n}\t\tNumber of servers. Defaults to 3");
		System.out.println("\t-r={n}\t\tNumber of request each clients will make. Default is 10");
		System.out.println("\t-y={n}\t\tCylinder size. Default is 1000");
		
		System.exit(0);
	}
}



// Client thread, which makes a fixed number of requests.
class Client extends Thread {
	private DiskScheduler scheduler = null;
	private int seed = 0;
	private int maxRequests = 0;
	private int numCylinders = 0;



	public Client(DiskScheduler s, int seed, int maxRequests, int numCylinders) {
		this.scheduler = s;
		this.seed = seed;
		this.maxRequests = maxRequests;
		this.numCylinders = numCylinders;
	}
	


	public void run() {
		int count = 0;
		Random random = new Random(seed);
		
		int s = random.nextInt(numCylinders);
		while(count++ < maxRequests) makeNextRequest(s++ % numCylinders);
	}



	private void makeNextRequest(int cyl) {
		Object req = scheduler.makeRequest(new DiskRequest(cyl));
	}

}



// Server keeps looking for requests until all clients have died.
class Server extends Thread {
	public boolean clientsAlive = true;
	private DiskScheduler scheduler = null;



	public Server(DiskScheduler s) {
		this.scheduler = s;
	}



	public void run() {
		int count = 0;
		Random random = new Random(1000);

		while (clientsAlive) getNextRequest(random.nextInt(1));
	}



	private void getNextRequest(int random) {
		synchronized(scheduler) {
			scheduler.getNextRequest();
			scheduler.finishedRequest("done");
		}
	}
}
