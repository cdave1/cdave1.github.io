// Copyright David Petrie 2008
//
// Implementation of a CSCAN scheduler.
//
// In this policy, requests are serviced in only one direction. In ascending
// order of cylinder number, for example. The request with the lowest cylinder
// number greater than the current head position is serviced first. If there
// is no such request, then the request with the least cylinder number is 
// chosen, and the requests are serviced in ascending order from there. This
// policy eventually services all requests, except in the unlikely event that
// there is a continual stream of requests for the same cylinder number.
import java.util.*;

public class CSCANScheduler implements DiskScheduler {
	private ArrayList<DiskRequest> requests;
	private DiskRequest currentRequest;
	private ArrayList distances = new ArrayList();
	private int distanceTravelled = 0;
	private int totalRequests = 0;
	private int currentCyl = 0;

	public CSCANScheduler() 
	{
		requests = new ArrayList();
		currentRequest = null;
	}



	// Publish a request to driver.
	// Wait for request to be completed.
	// Return the result of the request.
	//
	// Monitor equivalent: a waitC statement
	public Object makeRequest(DiskRequest req) {
		totalRequests++;
		synchronized(this) {
			requests.add(req);
			if (requests.size() == 1)
				this.notify();
		}
		req.waitUntilServiced();
		return req.getResult();
	}



	// Wait until there is another request.
	// Select a request and return it
	//
	// Needs to get the request on the queue NEAREST the
	// current request.
	public DiskRequest getNextRequest() {
		if (requests.size() > 0) {
			currentRequest = getNearestRequest();
		} else {
			try {
				while (requests.size() == 0) this.wait();
				currentRequest = requests.remove(0);
			} catch (InterruptedException e) {
				System.out.println("Server interrupted during wait.");
				return null;
			}
		}
		return currentRequest;
	}



	// Gets the nearest request to current request, as long as
	// the difference is greater than or equal to zero.
	// 
	// If we're at the end of the queue (current is higher than anything)
	// then get the lowest cylinder in the queue.
	private DiskRequest getNearestRequest() {
		
		int minDist = Integer.MAX_VALUE;
		DiskRequest ret = null;

		DiskRequest max = Collections.max(requests, new RequestComparer());
		if (currentCyl > max.getCyl()) {
			ret = Collections.min(requests, new RequestComparer());
			minDist = currentCyl - ret.getCyl();
		} else {
			for (DiskRequest req : requests) {
				int tmpDst = req.getCyl() - currentCyl;
				if (tmpDst >= 0) {
					if (tmpDst < minDist) {
						minDist = tmpDst;
						ret = req;
					}
				}
			}
		}
		distanceTravelled += minDist;
		distances.add(minDist);
		requests.remove(ret);

		currentCyl = ret.getCyl();
		return ret;
	}



	// Pass result to requesting process.
	public void finishedRequest(Object response) {
		currentRequest.setResponseAndNotify(response);
		currentRequest = null;
	}

	
	public int getDistanceTravelled() {
		return distanceTravelled;
	}



	public int getTotalRequests() {
		return totalRequests;
	}



	public ArrayList getStatsArray() {
		Collections.sort(distances);
		return distances;
	}



	public void printStats(boolean isVerbose) {
		if (isVerbose) {
			System.out.println("CSCAN:");
			System.out.println("Scheduler travelled " + getDistanceTravelled());
			System.out.println("Total requests: " + getTotalRequests());
			System.out.println("Average distance: " + getDistanceTravelled() / getTotalRequests());
			System.out.println("Max distance: " + getStatsArray().get(getStatsArray().size() -1));
		} else {
			System.out.print("CSCAN,");
			System.out.print(getDistanceTravelled() + ", ");
			System.out.print(getTotalRequests() + ", ");
			System.out.print(getDistanceTravelled() / getTotalRequests() + ", ");
			System.out.println(getStatsArray().get(getStatsArray().size() -1));
		}
	}
}



// Sorts a list of requests based on cylinder.
class RequestComparer implements Comparator
{
	public int compare(Object a, Object b)
	{
		if (((DiskRequest)a).getCyl() > ((DiskRequest)b).getCyl()) return 1;
		if (((DiskRequest)a).getCyl() == ((DiskRequest)b).getCyl()) return 0;
		return -1;
	}
}
