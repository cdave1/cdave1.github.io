// Copyright David Petrie 2008
//
// Driver for different implementations of DiskScheduler
//
// Instances of the Disk Scheduler interface will be used by several threads. There will be a server
// thread that does the following (not in any particular order):
// - Repeatedly calls getNextRequest() to obtain a new request
// - Once the request has been serviced calls finishedRequest(response) with the response from the 
//   request.
// 
// Also, there will be several client threads that repeatedly call makeRequest(req) to request disk
// access.
//
// The driver will test the properties of the different scheduling policies, so it will contain java
// threads that similate the server and client threads described above.
//
// Threads executing the makeRequest method must publish the request for the server to later process,
// and then wait until the processing is complete. 
//
// WHen the server thread invokes getNextRequest, it must:
// - Wait until a request is available
// - Choose a request based on the scheduling policy
// - Return the request.
// - Finally, the finishedRequest method must comminicate the reuslt of hte latest request to the thread
// that made it.

import java.util.*;

public class Driver {
	private static int numClients;
	private static int numServers;
	private static int maxClientRequests;
	private static int numCylinders;


	public static void main(String[] args) {
		if (args.length == 4) {
			numClients = max(0, Integer.parseInt(args[0]));
			numServers = max(0, Integer.parseInt(args[1]));
			maxClientRequests = max(0, Integer.parseInt(args[2]));
			numCylinders = max(0, Integer.parseInt(args[3]));
		} else if (args.length == 1) {
			if (args[0] == "-?") {
				printUsage();
			} else if (args[0] == "-d") {
				// use defaults
				numClients = 0;
				numServers = 3;
				maxClientRequests = 10;
				numCylinders = 1000;
			}
		} else if (args.length == 0) {
			printUsage();
		} else {
			printUsage();
		}


		SimpleScheduler simple = new SimpleScheduler();
		//DiskScheduler scheduler = new CSCANScheduler();
		DiskScheduler scheduler = new SSTScheduler();
		Client[] clients = new Client[20];

		

		Client client1 = new Client(scheduler, 1000);
		Client client2 = new Client(scheduler, 2000);
		Client client3 = new Client(scheduler, 3000);
		Server server1 = new Server(scheduler);
		Server server2 = new Server(scheduler);

		client1.start();
		client2.start();
		client3.start();
		server1.start();
		server2.start();

		while(client1.isAlive() || client2.isAlive() || client3.isAlive());
		server.clientsAlive = false;
		System.out.println("Scheduler travelled " + scheduler.getDistanceTravelled());
		System.exit(0);
		
	}



	private void printUsage() {
		System.out.print("USAGE: java Driver [Number of clients] [Number of servers] ");
		System.out.println("[maximum clients requests] [number of cylinders]");
		System.out.println("Or, try 'java Driver -d' to use default values");
		System.exit(0);
	}
}





class Client extends Thread {
	private DiskScheduler scheduler = null;
	private int seed = 0;
	private final int MAX_CYLINDER = 1000;

	public Client(DiskScheduler s, int seed) {
		this.scheduler = s;
		this.seed = seed;
	}
	
	public void run() {
		int count = 0;
		Random random = new Random(seed);
		
		while (count++ < 10) makeNextRequest(random.nextInt(MAX_CYLINDER));
	}

	private void makeNextRequest(int cyl) {
		Object req = scheduler.makeRequest(new DiskRequest(cyl));
	}

}

class Server extends Thread {
	public boolean clientsAlive = true;
	private Timer timer = null;
	private DiskScheduler scheduler = null;

	public Server(DiskScheduler s) {
		this.scheduler = s;
		timer = new Timer();
	}

	public void run() {
		int count = 0;
		Random random = new Random(1000);

		while (clientsAlive) getNextRequest(random.nextInt(1));
	}

	private void getNextRequest(int random) {
		//try { this.sleep(random);
		//} catch (InterruptedException e) {}

		synchronized(scheduler) {
			scheduler.getNextRequest();
			scheduler.finishedRequest("done");
		}
	}
}
