#define rand	pan_rand
#if defined(HAS_CODE) && defined(VERBOSE)
	printf("Pr: %d Tr: %d\n", II, t->forw);
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* PROC :init: */
	case 3: /* STATE 1 - line 274 "SST.promela" - [ReqList.size = 0] (0:0:1 - 1) */
		IfNotBlocked
		reached[2][1] = 1;
		(trpt+1)->bup.oval = now.ReqList.size;
		now.ReqList.size = 0;
#ifdef VAR_RANGES
		logval("ReqList.size", now.ReqList.size);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 4: /* STATE 2 - line 275 "SST.promela" - [(run Server())] (0:0:0 - 1) */
		IfNotBlocked
		reached[2][2] = 1;
		if (!(addproc(0, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 5: /* STATE 3 - line 276 "SST.promela" - [(run Client(0))] (0:0:0 - 1) */
		IfNotBlocked
		reached[2][3] = 1;
		if (!(addproc(1, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 6: /* STATE 4 - line 277 "SST.promela" - [(run Client(1))] (0:0:0 - 1) */
		IfNotBlocked
		reached[2][4] = 1;
		if (!(addproc(1, 1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 7: /* STATE 6 - line 279 "SST.promela" - [-end-] (0:0:0 - 1) */
		IfNotBlocked
		reached[2][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Client */
	case 8: /* STATE 1 - line 260 "SST.promela" - [((n<2))] (0:0:0 - 1) */
		IfNotBlocked
		reached[1][1] = 1;
		if (!((((P1 *)this)->n<2)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 9: /* STATE 2 - line 12 "SST.promela" - [(!(ReqRespMonitor.lock))] (34:0:1 - 1) */
		IfNotBlocked
		reached[1][2] = 1;
		if (!( !(((int)now.ReqRespMonitor.lock))))
			continue;
		/* merge: ReqRespMonitor.lock = 1(0, 3, 34) */
		reached[1][3] = 1;
		(trpt+1)->bup.oval = ((int)now.ReqRespMonitor.lock);
		now.ReqRespMonitor.lock = 1;
#ifdef VAR_RANGES
		logval("ReqRespMonitor.lock", ((int)now.ReqRespMonitor.lock));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 10: /* STATE 6 - line 82 "SST.promela" - [((ReqList.size==0))] (46:0:2 - 1) */
		IfNotBlocked
		reached[1][6] = 1;
		if (!((now.ReqList.size==0)))
			continue;
		/* merge: ReqList.reqs[0] = ((n+1)*10)(46, 7, 46) */
		reached[1][7] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.ReqList.reqs[0];
		now.ReqList.reqs[0] = ((((P1 *)this)->n+1)*10);
#ifdef VAR_RANGES
		logval("ReqList.reqs[0]", now.ReqList.reqs[0]);
#endif
		;
		/* merge: ReqList.size = (ReqList.size+1)(46, 8, 46) */
		reached[1][8] = 1;
		(trpt+1)->bup.ovals[1] = now.ReqList.size;
		now.ReqList.size = (now.ReqList.size+1);
#ifdef VAR_RANGES
		logval("ReqList.size", now.ReqList.size);
#endif
		;
		/* merge: .(goto)(46, 31, 46) */
		reached[1][31] = 1;
		;
		/* merge: printf('Added %d',((n+1)*10))(46, 33, 46) */
		reached[1][33] = 1;
		Printf("Added %d", ((((P1 *)this)->n+1)*10));
		_m = 3; goto P999; /* 4 */
	case 11: /* STATE 31 - line 100 "SST.promela" - [.(goto)] (0:46:0 - 2) */
		IfNotBlocked
		reached[1][31] = 1;
		;
		/* merge: printf('Added %d',((n+1)*10))(46, 33, 46) */
		reached[1][33] = 1;
		Printf("Added %d", ((((P1 *)this)->n+1)*10));
		_m = 3; goto P999; /* 1 */
	case 12: /* STATE 10 - line 84 "SST.promela" - [pos = 0] (0:16:2 - 1) */
		IfNotBlocked
		reached[1][10] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P1 *)this)->pos;
		((P1 *)this)->pos = 0;
#ifdef VAR_RANGES
		logval("Client:pos", ((P1 *)this)->pos);
#endif
		;
		/* merge: idx = 0(16, 11, 16) */
		reached[1][11] = 1;
		(trpt+1)->bup.ovals[1] = ((P1 *)this)->idx;
		((P1 *)this)->idx = 0;
#ifdef VAR_RANGES
		logval("Client:idx", ((P1 *)this)->idx);
#endif
		;
		/* merge: .(goto)(0, 17, 16) */
		reached[1][17] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 13: /* STATE 12 - line 87 "SST.promela" - [(((idx<ReqList.size)&&(((n+1)*10)>ReqList.reqs[idx])))] (16:0:1 - 1) */
		IfNotBlocked
		reached[1][12] = 1;
		if (!(((((P1 *)this)->idx<now.ReqList.size)&&(((((P1 *)this)->n+1)*10)>now.ReqList.reqs[ Index(((P1 *)this)->idx, 2) ]))))
			continue;
		/* merge: idx = (idx+1)(0, 13, 16) */
		reached[1][13] = 1;
		(trpt+1)->bup.oval = ((P1 *)this)->idx;
		((P1 *)this)->idx = (((P1 *)this)->idx+1);
#ifdef VAR_RANGES
		logval("Client:idx", ((P1 *)this)->idx);
#endif
		;
		/* merge: .(goto)(0, 17, 16) */
		reached[1][17] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 14: /* STATE 19 - line 90 "SST.promela" - [pos = ReqList.size] (0:25:1 - 3) */
		IfNotBlocked
		reached[1][19] = 1;
		(trpt+1)->bup.oval = ((P1 *)this)->pos;
		((P1 *)this)->pos = now.ReqList.size;
#ifdef VAR_RANGES
		logval("Client:pos", ((P1 *)this)->pos);
#endif
		;
		/* merge: .(goto)(0, 26, 25) */
		reached[1][26] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 15: /* STATE 20 - line 93 "SST.promela" - [((pos>idx))] (25:0:2 - 1) */
		IfNotBlocked
		reached[1][20] = 1;
		if (!((((P1 *)this)->pos>((P1 *)this)->idx)))
			continue;
		/* merge: ReqList.reqs[pos] = ReqList.reqs[(pos+1)](25, 21, 25) */
		reached[1][21] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.ReqList.reqs[ Index(((P1 *)this)->pos, 2) ];
		now.ReqList.reqs[ Index(((P1 *)this)->pos, 2) ] = now.ReqList.reqs[ Index((((P1 *)this)->pos+1), 2) ];
#ifdef VAR_RANGES
		logval("ReqList.reqs[Client:pos]", now.ReqList.reqs[ Index(((P1 *)this)->pos, 2) ]);
#endif
		;
		/* merge: pos = (pos-1)(25, 22, 25) */
		reached[1][22] = 1;
		(trpt+1)->bup.ovals[1] = ((P1 *)this)->pos;
		((P1 *)this)->pos = (((P1 *)this)->pos-1);
#ifdef VAR_RANGES
		logval("Client:pos", ((P1 *)this)->pos);
#endif
		;
		/* merge: .(goto)(0, 26, 25) */
		reached[1][26] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 16: /* STATE 28 - line 97 "SST.promela" - [ReqList.reqs[idx] = ((n+1)*10)] (0:46:2 - 3) */
		IfNotBlocked
		reached[1][28] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.ReqList.reqs[ Index(((P1 *)this)->idx, 2) ];
		now.ReqList.reqs[ Index(((P1 *)this)->idx, 2) ] = ((((P1 *)this)->n+1)*10);
#ifdef VAR_RANGES
		logval("ReqList.reqs[Client:idx]", now.ReqList.reqs[ Index(((P1 *)this)->idx, 2) ]);
#endif
		;
		/* merge: ReqList.size = (ReqList.size+1)(46, 29, 46) */
		reached[1][29] = 1;
		(trpt+1)->bup.ovals[1] = now.ReqList.size;
		now.ReqList.size = (now.ReqList.size+1);
#ifdef VAR_RANGES
		logval("ReqList.size", now.ReqList.size);
#endif
		;
		/* merge: .(goto)(46, 31, 46) */
		reached[1][31] = 1;
		;
		/* merge: printf('Added %d',((n+1)*10))(46, 33, 46) */
		reached[1][33] = 1;
		Printf("Added %d", ((((P1 *)this)->n+1)*10));
		_m = 3; goto P999; /* 3 */
	case 17: /* STATE 35 - line 192 "SST.promela" - [((ReqList.size==1))] (0:0:0 - 1) */
		IfNotBlocked
		reached[1][35] = 1;
		if (!((now.ReqList.size==1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 18: /* STATE 36 - line 46 "SST.promela" - [(!((ReqRespMonitor.waiting==0)))] (71:0:1 - 1) */
		IfNotBlocked
		reached[1][36] = 1;
		if (!( !((now.ReqRespMonitor.waiting==0))))
			continue;
		/* merge: ReqRespMonitor.gate = (ReqRespMonitor.gate+1)(71, 37, 71) */
		reached[1][37] = 1;
		(trpt+1)->bup.oval = now.ReqRespMonitor.gate;
		now.ReqRespMonitor.gate = (now.ReqRespMonitor.gate+1);
#ifdef VAR_RANGES
		logval("ReqRespMonitor.gate", now.ReqRespMonitor.gate);
#endif
		;
		/* merge: .(goto)(71, 41, 71) */
		reached[1][41] = 1;
		;
		/* merge: .(goto)(0, 47, 71) */
		reached[1][47] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 19: /* STATE 41 - line 49 "SST.promela" - [.(goto)] (0:71:0 - 2) */
		IfNotBlocked
		reached[1][41] = 1;
		;
		/* merge: .(goto)(0, 47, 71) */
		reached[1][47] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 20: /* STATE 39 - line 47 "SST.promela" - [(1)] (71:0:0 - 1) */
		IfNotBlocked
		reached[1][39] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(71, 41, 71) */
		reached[1][41] = 1;
		;
		/* merge: .(goto)(0, 47, 71) */
		reached[1][47] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 21: /* STATE 48 - line 12 "SST.promela" - [(!(Reqs[r].mon.lock))] (66:0:1 - 1) */
		IfNotBlocked
		reached[1][48] = 1;
		if (!( !(((int)now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.lock))))
			continue;
		/* merge: Reqs[r].mon.lock = 1(0, 49, 66) */
		reached[1][49] = 1;
		(trpt+1)->bup.oval = ((int)now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.lock);
		now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.lock = 1;
#ifdef VAR_RANGES
		logval("Reqs[Client:r].mon.lock", ((int)now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.lock));
#endif
		;
		/* merge: .(goto)(0, 67, 66) */
		reached[1][67] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 22: /* STATE 52 - line 167 "SST.promela" - [(!(Reqs[r].finished))] (0:0:0 - 1) */
		IfNotBlocked
		reached[1][52] = 1;
		if (!( !(((int)now.Reqs[ Index(((P1 *)this)->r, 2) ].finished))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 23: /* STATE 53 - line 34 "SST.promela" - [Reqs[r].mon.waiting = (Reqs[r].mon.waiting+1)] (0:55:2 - 1) */
		IfNotBlocked
		reached[1][53] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.waiting;
		now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.waiting = (now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.waiting+1);
#ifdef VAR_RANGES
		logval("Reqs[Client:r].mon.waiting", now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.waiting);
#endif
		;
		/* merge: Reqs[r].mon.lock = 0(55, 54, 55) */
		reached[1][54] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.lock);
		now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.lock = 0;
#ifdef VAR_RANGES
		logval("Reqs[Client:r].mon.lock", ((int)now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.lock));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 24: /* STATE 55 - line 36 "SST.promela" - [((Reqs[r].mon.gate>0))] (58:0:1 - 1) */
		IfNotBlocked
		reached[1][55] = 1;
		if (!((now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.gate>0)))
			continue;
		/* merge: assert((Reqs[r].mon.gate>0))(58, 56, 58) */
		reached[1][56] = 1;
		assert((now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.gate>0), "(Reqs[r].mon.gate>0)", II, tt, t);
		/* merge: Reqs[r].mon.gate = (Reqs[r].mon.gate-1)(58, 57, 58) */
		reached[1][57] = 1;
		(trpt+1)->bup.oval = now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.gate;
		now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.gate = (now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.gate-1);
#ifdef VAR_RANGES
		logval("Reqs[Client:r].mon.gate", now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.gate);
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 25: /* STATE 58 - line 38 "SST.promela" - [(!(Reqs[r].mon.lock))] (66:0:2 - 1) */
		IfNotBlocked
		reached[1][58] = 1;
		if (!( !(((int)now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.lock))))
			continue;
		/* merge: assert(!(Reqs[r].mon.lock))(66, 59, 66) */
		reached[1][59] = 1;
		assert( !(((int)now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.lock)), " !(Reqs[r].mon.lock)", II, tt, t);
		/* merge: Reqs[r].mon.lock = 1(66, 60, 66) */
		reached[1][60] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.lock);
		now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.lock = 1;
#ifdef VAR_RANGES
		logval("Reqs[Client:r].mon.lock", ((int)now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.lock));
#endif
		;
		/* merge: Reqs[r].mon.waiting = (Reqs[r].mon.waiting-1)(66, 61, 66) */
		reached[1][61] = 1;
		(trpt+1)->bup.ovals[1] = now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.waiting;
		now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.waiting = (now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.waiting-1);
#ifdef VAR_RANGES
		logval("Reqs[Client:r].mon.waiting", now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.waiting);
#endif
		;
		/* merge: .(goto)(0, 67, 66) */
		reached[1][67] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 26: /* STATE 69 - line 18 "SST.promela" - [Reqs[r].mon.lock = 0] (0:0:1 - 1) */
		IfNotBlocked
		reached[1][69] = 1;
		(trpt+1)->bup.oval = ((int)now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.lock);
		now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.lock = 0;
#ifdef VAR_RANGES
		logval("Reqs[Client:r].mon.lock", ((int)now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.lock));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 27: /* STATE 72 - line 197 "SST.promela" - [assert(1)] (0:0:0 - 1) */
		IfNotBlocked
		reached[1][72] = 1;
		assert(1, "1", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 28: /* STATE 73 - line 18 "SST.promela" - [ReqRespMonitor.lock = 0] (0:0:1 - 1) */
		IfNotBlocked
		reached[1][73] = 1;
		(trpt+1)->bup.oval = ((int)now.ReqRespMonitor.lock);
		now.ReqRespMonitor.lock = 0;
#ifdef VAR_RANGES
		logval("ReqRespMonitor.lock", ((int)now.ReqRespMonitor.lock));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 29: /* STATE 76 - line 263 "SST.promela" - [assert(Reqs[r].finished)] (0:0:0 - 1) */
		IfNotBlocked
		reached[1][76] = 1;
		assert(((int)now.Reqs[ Index(((P1 *)this)->r, 2) ].finished), "Reqs[r].finished", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 30: /* STATE 77 - line 154 "SST.promela" - [Reqs[r].finished = 0] (0:0:1 - 1) */
		IfNotBlocked
		reached[1][77] = 1;
		(trpt+1)->bup.oval = ((int)now.Reqs[ Index(((P1 *)this)->r, 2) ].finished);
		now.Reqs[ Index(((P1 *)this)->r, 2) ].finished = 0;
#ifdef VAR_RANGES
		logval("Reqs[Client:r].finished", ((int)now.Reqs[ Index(((P1 *)this)->r, 2) ].finished));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 31: /* STATE 78 - line 26 "SST.promela" - [Reqs[r].mon.lock = 0] (0:87:4 - 1) */
		IfNotBlocked
		reached[1][78] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.lock);
		now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.lock = 0;
#ifdef VAR_RANGES
		logval("Reqs[Client:r].mon.lock", ((int)now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.lock));
#endif
		;
		/* merge: Reqs[r].mon.gate = 0(87, 79, 87) */
		reached[1][79] = 1;
		(trpt+1)->bup.ovals[1] = now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.gate;
		now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.gate = 0;
#ifdef VAR_RANGES
		logval("Reqs[Client:r].mon.gate", now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.gate);
#endif
		;
		/* merge: Reqs[r].mon.waiting = 0(87, 80, 87) */
		reached[1][80] = 1;
		(trpt+1)->bup.ovals[2] = now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.waiting;
		now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.waiting = 0;
#ifdef VAR_RANGES
		logval("Reqs[Client:r].mon.waiting", now.Reqs[ Index(((P1 *)this)->r, 2) ].mon.waiting);
#endif
		;
		/* merge: n = (n+1)(87, 83, 87) */
		reached[1][83] = 1;
		(trpt+1)->bup.ovals[3] = ((P1 *)this)->n;
		((P1 *)this)->n = (((P1 *)this)->n+1);
#ifdef VAR_RANGES
		logval("Client:n", ((P1 *)this)->n);
#endif
		;
		/* merge: .(goto)(0, 88, 87) */
		reached[1][88] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 32: /* STATE 90 - line 267 "SST.promela" - [-end-] (0:0:0 - 3) */
		IfNotBlocked
		reached[1][90] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Server */
	case 33: /* STATE 1 - line 245 "SST.promela" - [((ReqList.size<(2*2)))] (0:0:0 - 1) */
		IfNotBlocked
		reached[0][1] = 1;
		if (!((now.ReqList.size<(2*2))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 34: /* STATE 2 - line 12 "SST.promela" - [(!(ReqRespMonitor.lock))] (87:0:1 - 1) */
		IfNotBlocked
		reached[0][2] = 1;
		if (!( !(((int)now.ReqRespMonitor.lock))))
			continue;
		/* merge: ReqRespMonitor.lock = 1(0, 3, 87) */
		reached[0][3] = 1;
		(trpt+1)->bup.oval = ((int)now.ReqRespMonitor.lock);
		now.ReqRespMonitor.lock = 1;
#ifdef VAR_RANGES
		logval("ReqRespMonitor.lock", ((int)now.ReqRespMonitor.lock));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 35: /* STATE 6 - line 207 "SST.promela" - [((ReqList.size==0))] (0:0:0 - 1) */
		IfNotBlocked
		reached[0][6] = 1;
		if (!((now.ReqList.size==0)))
			continue;
		_m = 3; goto P999; /* 0 */
/* STATE 7 - line 209 "SST.promela" - [((ReqList.size==0))] (0:0 - 1) same as 35 (0:0 - 1) */
	case 36: /* STATE 8 - line 34 "SST.promela" - [ReqRespMonitor.waiting = (ReqRespMonitor.waiting+1)] (0:10:2 - 1) */
		IfNotBlocked
		reached[0][8] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.ReqRespMonitor.waiting;
		now.ReqRespMonitor.waiting = (now.ReqRespMonitor.waiting+1);
#ifdef VAR_RANGES
		logval("ReqRespMonitor.waiting", now.ReqRespMonitor.waiting);
#endif
		;
		/* merge: ReqRespMonitor.lock = 0(10, 9, 10) */
		reached[0][9] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.ReqRespMonitor.lock);
		now.ReqRespMonitor.lock = 0;
#ifdef VAR_RANGES
		logval("ReqRespMonitor.lock", ((int)now.ReqRespMonitor.lock));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 37: /* STATE 10 - line 36 "SST.promela" - [((ReqRespMonitor.gate>0))] (13:0:1 - 1) */
		IfNotBlocked
		reached[0][10] = 1;
		if (!((now.ReqRespMonitor.gate>0)))
			continue;
		/* merge: assert((ReqRespMonitor.gate>0))(13, 11, 13) */
		reached[0][11] = 1;
		assert((now.ReqRespMonitor.gate>0), "(ReqRespMonitor.gate>0)", II, tt, t);
		/* merge: ReqRespMonitor.gate = (ReqRespMonitor.gate-1)(13, 12, 13) */
		reached[0][12] = 1;
		(trpt+1)->bup.oval = now.ReqRespMonitor.gate;
		now.ReqRespMonitor.gate = (now.ReqRespMonitor.gate-1);
#ifdef VAR_RANGES
		logval("ReqRespMonitor.gate", now.ReqRespMonitor.gate);
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 38: /* STATE 13 - line 38 "SST.promela" - [(!(ReqRespMonitor.lock))] (52:0:2 - 1) */
		IfNotBlocked
		reached[0][13] = 1;
		if (!( !(((int)now.ReqRespMonitor.lock))))
			continue;
		/* merge: assert(!(ReqRespMonitor.lock))(52, 14, 52) */
		reached[0][14] = 1;
		assert( !(((int)now.ReqRespMonitor.lock)), " !(ReqRespMonitor.lock)", II, tt, t);
		/* merge: ReqRespMonitor.lock = 1(52, 15, 52) */
		reached[0][15] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.ReqRespMonitor.lock);
		now.ReqRespMonitor.lock = 1;
#ifdef VAR_RANGES
		logval("ReqRespMonitor.lock", ((int)now.ReqRespMonitor.lock));
#endif
		;
		/* merge: ReqRespMonitor.waiting = (ReqRespMonitor.waiting-1)(52, 16, 52) */
		reached[0][16] = 1;
		(trpt+1)->bup.ovals[1] = now.ReqRespMonitor.waiting;
		now.ReqRespMonitor.waiting = (now.ReqRespMonitor.waiting-1);
#ifdef VAR_RANGES
		logval("ReqRespMonitor.waiting", now.ReqRespMonitor.waiting);
#endif
		;
		/* merge: .(goto)(0, 53, 52) */
		reached[0][53] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 39: /* STATE 20 - line 110 "SST.promela" - [idx1 = 0] (0:46:2 - 1) */
		IfNotBlocked
		reached[0][20] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P0 *)this)->idx1;
		((P0 *)this)->idx1 = 0;
#ifdef VAR_RANGES
		logval("Server:idx1", ((P0 *)this)->idx1);
#endif
		;
		/* merge: idx2 = (ReqList.size-1)(46, 21, 46) */
		reached[0][21] = 1;
		(trpt+1)->bup.ovals[1] = ((P0 *)this)->idx2;
		((P0 *)this)->idx2 = (now.ReqList.size-1);
#ifdef VAR_RANGES
		logval("Server:idx2", ((P0 *)this)->idx2);
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 40: /* STATE 22 - line 113 "SST.promela" - [((ReqList.size==1))] (89:0:2 - 1) */
		IfNotBlocked
		reached[0][22] = 1;
		if (!((now.ReqList.size==1)))
			continue;
		/* merge: currentRequest = ReqList.reqs[0](89, 23, 89) */
		reached[0][23] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.currentRequest;
		now.currentRequest = now.ReqList.reqs[0];
#ifdef VAR_RANGES
		logval("currentRequest", now.currentRequest);
#endif
		;
		/* merge: ReqList.size = 0(89, 24, 89) */
		reached[0][24] = 1;
		(trpt+1)->bup.ovals[1] = now.ReqList.size;
		now.ReqList.size = 0;
#ifdef VAR_RANGES
		logval("ReqList.size", now.ReqList.size);
#endif
		;
		/* merge: .(goto)(89, 47, 89) */
		reached[0][47] = 1;
		;
		/* merge: assert(1)(89, 49, 89) */
		reached[0][49] = 1;
		assert(1, "1", II, tt, t);
		/* merge: goto :b1(0, 51, 89) */
		reached[0][51] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 41: /* STATE 47 - line 130 "SST.promela" - [.(goto)] (0:89:0 - 2) */
		IfNotBlocked
		reached[0][47] = 1;
		;
		/* merge: assert(1)(89, 49, 89) */
		reached[0][49] = 1;
		assert(1, "1", II, tt, t);
		/* merge: goto :b1(0, 51, 89) */
		reached[0][51] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 42: /* STATE 26 - line 116 "SST.promela" - [(((idx1<ReqList.size)&&(ReqList.reqs[idx1]<=currentRequest)))] (30:0:1 - 1) */
		IfNotBlocked
		reached[0][26] = 1;
		if (!(((((P0 *)this)->idx1<now.ReqList.size)&&(now.ReqList.reqs[ Index(((P0 *)this)->idx1, 2) ]<=now.currentRequest))))
			continue;
		/* merge: idx1 = (idx1+1)(0, 27, 30) */
		reached[0][27] = 1;
		(trpt+1)->bup.oval = ((P0 *)this)->idx1;
		((P0 *)this)->idx1 = (((P0 *)this)->idx1+1);
#ifdef VAR_RANGES
		logval("Server:idx1", ((P0 *)this)->idx1);
#endif
		;
		/* merge: .(goto)(0, 31, 30) */
		reached[0][31] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 43: /* STATE 33 - line 121 "SST.promela" - [(((idx2>idx1)&&(ReqList.reqs[idx2]>=currentRequest)))] (37:0:1 - 1) */
		IfNotBlocked
		reached[0][33] = 1;
		if (!(((((P0 *)this)->idx2>((P0 *)this)->idx1)&&(now.ReqList.reqs[ Index(((P0 *)this)->idx2, 2) ]>=now.currentRequest))))
			continue;
		/* merge: idx2 = (idx2-1)(0, 34, 37) */
		reached[0][34] = 1;
		(trpt+1)->bup.oval = ((P0 *)this)->idx2;
		((P0 *)this)->idx2 = (((P0 *)this)->idx2-1);
#ifdef VAR_RANGES
		logval("Server:idx2", ((P0 *)this)->idx2);
#endif
		;
		/* merge: .(goto)(0, 38, 37) */
		reached[0][38] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 44: /* STATE 40 - line 126 "SST.promela" - [((idx1==idx2))] (89:0:2 - 1) */
		IfNotBlocked
		reached[0][40] = 1;
		if (!((((P0 *)this)->idx1==((P0 *)this)->idx2)))
			continue;
		/* dead 1: idx2 */  (trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P0 *)this)->idx2;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)this)->idx2 = 0;
		/* merge: currentRequest = ReqList.reqs[idx1](89, 41, 89) */
		reached[0][41] = 1;
		(trpt+1)->bup.ovals[1] = now.currentRequest;
		now.currentRequest = now.ReqList.reqs[ Index(((P0 *)this)->idx1, 2) ];
#ifdef VAR_RANGES
		logval("currentRequest", now.currentRequest);
#endif
		;
		/* merge: .(goto)(89, 45, 89) */
		reached[0][45] = 1;
		;
		/* merge: .(goto)(89, 47, 89) */
		reached[0][47] = 1;
		;
		/* merge: assert(1)(89, 49, 89) */
		reached[0][49] = 1;
		assert(1, "1", II, tt, t);
		/* merge: goto :b1(0, 51, 89) */
		reached[0][51] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 45: /* STATE 45 - line 129 "SST.promela" - [.(goto)] (0:89:0 - 2) */
		IfNotBlocked
		reached[0][45] = 1;
		;
		/* merge: .(goto)(89, 47, 89) */
		reached[0][47] = 1;
		;
		/* merge: assert(1)(89, 49, 89) */
		reached[0][49] = 1;
		assert(1, "1", II, tt, t);
		/* merge: goto :b1(0, 51, 89) */
		reached[0][51] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 46: /* STATE 43 - line 127 "SST.promela" - [(1)] (89:0:0 - 1) */
		IfNotBlocked
		reached[0][43] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(89, 45, 89) */
		reached[0][45] = 1;
		;
		/* merge: .(goto)(89, 47, 89) */
		reached[0][47] = 1;
		;
		/* merge: assert(1)(89, 49, 89) */
		reached[0][49] = 1;
		assert(1, "1", II, tt, t);
		/* merge: goto :b1(0, 51, 89) */
		reached[0][51] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 47: /* STATE 56 - line 110 "SST.promela" - [idx1 = 0] (0:82:2 - 1) */
		IfNotBlocked
		reached[0][56] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P0 *)this)->idx1;
		((P0 *)this)->idx1 = 0;
#ifdef VAR_RANGES
		logval("Server:idx1", ((P0 *)this)->idx1);
#endif
		;
		/* merge: idx2 = (ReqList.size-1)(82, 57, 82) */
		reached[0][57] = 1;
		(trpt+1)->bup.ovals[1] = ((P0 *)this)->idx2;
		((P0 *)this)->idx2 = (now.ReqList.size-1);
#ifdef VAR_RANGES
		logval("Server:idx2", ((P0 *)this)->idx2);
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 48: /* STATE 58 - line 113 "SST.promela" - [((ReqList.size==1))] (89:0:2 - 1) */
		IfNotBlocked
		reached[0][58] = 1;
		if (!((now.ReqList.size==1)))
			continue;
		/* merge: currentRequest = ReqList.reqs[0](89, 59, 89) */
		reached[0][59] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.currentRequest;
		now.currentRequest = now.ReqList.reqs[0];
#ifdef VAR_RANGES
		logval("currentRequest", now.currentRequest);
#endif
		;
		/* merge: ReqList.size = 0(89, 60, 89) */
		reached[0][60] = 1;
		(trpt+1)->bup.ovals[1] = now.ReqList.size;
		now.ReqList.size = 0;
#ifdef VAR_RANGES
		logval("ReqList.size", now.ReqList.size);
#endif
		;
		/* merge: .(goto)(89, 83, 89) */
		reached[0][83] = 1;
		;
		/* merge: assert(1)(89, 85, 89) */
		reached[0][85] = 1;
		assert(1, "1", II, tt, t);
		/* merge: .(goto)(0, 88, 89) */
		reached[0][88] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 49: /* STATE 83 - line 130 "SST.promela" - [.(goto)] (0:89:0 - 2) */
		IfNotBlocked
		reached[0][83] = 1;
		;
		/* merge: assert(1)(89, 85, 89) */
		reached[0][85] = 1;
		assert(1, "1", II, tt, t);
		/* merge: .(goto)(0, 88, 89) */
		reached[0][88] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 50: /* STATE 62 - line 116 "SST.promela" - [(((idx1<ReqList.size)&&(ReqList.reqs[idx1]<=currentRequest)))] (66:0:1 - 1) */
		IfNotBlocked
		reached[0][62] = 1;
		if (!(((((P0 *)this)->idx1<now.ReqList.size)&&(now.ReqList.reqs[ Index(((P0 *)this)->idx1, 2) ]<=now.currentRequest))))
			continue;
		/* merge: idx1 = (idx1+1)(0, 63, 66) */
		reached[0][63] = 1;
		(trpt+1)->bup.oval = ((P0 *)this)->idx1;
		((P0 *)this)->idx1 = (((P0 *)this)->idx1+1);
#ifdef VAR_RANGES
		logval("Server:idx1", ((P0 *)this)->idx1);
#endif
		;
		/* merge: .(goto)(0, 67, 66) */
		reached[0][67] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 51: /* STATE 69 - line 121 "SST.promela" - [(((idx2>idx1)&&(ReqList.reqs[idx2]>=currentRequest)))] (73:0:1 - 1) */
		IfNotBlocked
		reached[0][69] = 1;
		if (!(((((P0 *)this)->idx2>((P0 *)this)->idx1)&&(now.ReqList.reqs[ Index(((P0 *)this)->idx2, 2) ]>=now.currentRequest))))
			continue;
		/* merge: idx2 = (idx2-1)(0, 70, 73) */
		reached[0][70] = 1;
		(trpt+1)->bup.oval = ((P0 *)this)->idx2;
		((P0 *)this)->idx2 = (((P0 *)this)->idx2-1);
#ifdef VAR_RANGES
		logval("Server:idx2", ((P0 *)this)->idx2);
#endif
		;
		/* merge: .(goto)(0, 74, 73) */
		reached[0][74] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 52: /* STATE 76 - line 126 "SST.promela" - [((idx1==idx2))] (89:0:2 - 1) */
		IfNotBlocked
		reached[0][76] = 1;
		if (!((((P0 *)this)->idx1==((P0 *)this)->idx2)))
			continue;
		/* dead 1: idx2 */  (trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P0 *)this)->idx2;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)this)->idx2 = 0;
		/* merge: currentRequest = ReqList.reqs[idx1](89, 77, 89) */
		reached[0][77] = 1;
		(trpt+1)->bup.ovals[1] = now.currentRequest;
		now.currentRequest = now.ReqList.reqs[ Index(((P0 *)this)->idx1, 2) ];
#ifdef VAR_RANGES
		logval("currentRequest", now.currentRequest);
#endif
		;
		/* merge: .(goto)(89, 81, 89) */
		reached[0][81] = 1;
		;
		/* merge: .(goto)(89, 83, 89) */
		reached[0][83] = 1;
		;
		/* merge: assert(1)(89, 85, 89) */
		reached[0][85] = 1;
		assert(1, "1", II, tt, t);
		/* merge: .(goto)(0, 88, 89) */
		reached[0][88] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 53: /* STATE 81 - line 129 "SST.promela" - [.(goto)] (0:89:0 - 2) */
		IfNotBlocked
		reached[0][81] = 1;
		;
		/* merge: .(goto)(89, 83, 89) */
		reached[0][83] = 1;
		;
		/* merge: assert(1)(89, 85, 89) */
		reached[0][85] = 1;
		assert(1, "1", II, tt, t);
		/* merge: .(goto)(0, 88, 89) */
		reached[0][88] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 54: /* STATE 79 - line 127 "SST.promela" - [(1)] (89:0:0 - 1) */
		IfNotBlocked
		reached[0][79] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(89, 81, 89) */
		reached[0][81] = 1;
		;
		/* merge: .(goto)(89, 83, 89) */
		reached[0][83] = 1;
		;
		/* merge: assert(1)(89, 85, 89) */
		reached[0][85] = 1;
		assert(1, "1", II, tt, t);
		/* merge: .(goto)(0, 88, 89) */
		reached[0][88] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 55: /* STATE 89 - line 215 "SST.promela" - [outR = currentRequest] (0:0:2 - 5) */
		IfNotBlocked
		reached[0][89] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P0 *)this)->outR;
		((P0 *)this)->outR = now.currentRequest;
#ifdef VAR_RANGES
		logval("Server:outR", ((P0 *)this)->outR);
#endif
		;
		/* dead 2: outR */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)this)->outR = 0;
		_m = 3; goto P999; /* 0 */
	case 56: /* STATE 90 - line 18 "SST.promela" - [ReqRespMonitor.lock = 0] (0:0:1 - 1) */
		IfNotBlocked
		reached[0][90] = 1;
		(trpt+1)->bup.oval = ((int)now.ReqRespMonitor.lock);
		now.ReqRespMonitor.lock = 0;
#ifdef VAR_RANGES
		logval("ReqRespMonitor.lock", ((int)now.ReqRespMonitor.lock));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 57: /* STATE 93 - line 12 "SST.promela" - [(!(ReqRespMonitor.lock))] (112:0:1 - 1) */
		IfNotBlocked
		reached[0][93] = 1;
		if (!( !(((int)now.ReqRespMonitor.lock))))
			continue;
		/* merge: ReqRespMonitor.lock = 1(0, 94, 112) */
		reached[0][94] = 1;
		(trpt+1)->bup.oval = ((int)now.ReqRespMonitor.lock);
		now.ReqRespMonitor.lock = 1;
#ifdef VAR_RANGES
		logval("ReqRespMonitor.lock", ((int)now.ReqRespMonitor.lock));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 58: /* STATE 97 - line 12 "SST.promela" - [(!(Reqs[currentRequest].mon.lock))] (101:0:1 - 1) */
		IfNotBlocked
		reached[0][97] = 1;
		if (!( !(((int)now.Reqs[ Index(now.currentRequest, 2) ].mon.lock))))
			continue;
		/* merge: Reqs[currentRequest].mon.lock = 1(0, 98, 101) */
		reached[0][98] = 1;
		(trpt+1)->bup.oval = ((int)now.Reqs[ Index(now.currentRequest, 2) ].mon.lock);
		now.Reqs[ Index(now.currentRequest, 2) ].mon.lock = 1;
#ifdef VAR_RANGES
		logval("Reqs[currentRequest].mon.lock", ((int)now.Reqs[ Index(now.currentRequest, 2) ].mon.lock));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 59: /* STATE 101 - line 179 "SST.promela" - [Reqs[currentRequest].finished = 1] (0:0:1 - 1) */
		IfNotBlocked
		reached[0][101] = 1;
		(trpt+1)->bup.oval = ((int)now.Reqs[ Index(now.currentRequest, 2) ].finished);
		now.Reqs[ Index(now.currentRequest, 2) ].finished = 1;
#ifdef VAR_RANGES
		logval("Reqs[currentRequest].finished", ((int)now.Reqs[ Index(now.currentRequest, 2) ].finished));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 60: /* STATE 102 - line 46 "SST.promela" - [(!((Reqs[currentRequest].mon.waiting==0)))] (111:0:1 - 1) */
		IfNotBlocked
		reached[0][102] = 1;
		if (!( !((now.Reqs[ Index(now.currentRequest, 2) ].mon.waiting==0))))
			continue;
		/* merge: Reqs[currentRequest].mon.gate = (Reqs[currentRequest].mon.gate+1)(111, 103, 111) */
		reached[0][103] = 1;
		(trpt+1)->bup.oval = now.Reqs[ Index(now.currentRequest, 2) ].mon.gate;
		now.Reqs[ Index(now.currentRequest, 2) ].mon.gate = (now.Reqs[ Index(now.currentRequest, 2) ].mon.gate+1);
#ifdef VAR_RANGES
		logval("Reqs[currentRequest].mon.gate", now.Reqs[ Index(now.currentRequest, 2) ].mon.gate);
#endif
		;
		/* merge: .(goto)(111, 107, 111) */
		reached[0][107] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 61: /* STATE 107 - line 49 "SST.promela" - [.(goto)] (0:111:0 - 2) */
		IfNotBlocked
		reached[0][107] = 1;
		;
		_m = 3; goto P999; /* 0 */
	case 62: /* STATE 105 - line 47 "SST.promela" - [(1)] (111:0:0 - 1) */
		IfNotBlocked
		reached[0][105] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(111, 107, 111) */
		reached[0][107] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 63: /* STATE 110 - line 18 "SST.promela" - [Reqs[currentRequest].mon.lock = 0] (0:0:1 - 1) */
		IfNotBlocked
		reached[0][110] = 1;
		(trpt+1)->bup.oval = ((int)now.Reqs[ Index(now.currentRequest, 2) ].mon.lock);
		now.Reqs[ Index(now.currentRequest, 2) ].mon.lock = 0;
#ifdef VAR_RANGES
		logval("Reqs[currentRequest].mon.lock", ((int)now.Reqs[ Index(now.currentRequest, 2) ].mon.lock));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 64: /* STATE 113 - line 225 "SST.promela" - [currentRequest = -(1)] (0:0:1 - 1) */
		IfNotBlocked
		reached[0][113] = 1;
		(trpt+1)->bup.oval = now.currentRequest;
		now.currentRequest =  -(1);
#ifdef VAR_RANGES
		logval("currentRequest", now.currentRequest);
#endif
		;
		_m = 3; goto P999; /* 0 */
/* STATE 114 - line 18 "SST.promela" - [ReqRespMonitor.lock = 0] (0:0 - 1) same as 56 (0:0 - 1) */
	case 65: /* STATE 122 - line 249 "SST.promela" - [-end-] (0:0:0 - 3) */
		IfNotBlocked
		reached[0][122] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

