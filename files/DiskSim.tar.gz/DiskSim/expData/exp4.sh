#!/bin/bash
# Clients proportional to servers.
echo "SST"
java Driver -e -t s -r 100 -c 5 -s 5
java Driver -e -t s -r 100 -c 10 -s 10
java Driver -e -t s -r 100 -c 15 -s 15
java Driver -e -t s -r 100 -c 20 -s 20
java Driver -e -t s -r 100 -c 25 -s 25
java Driver -e -t s -r 100 -c 30 -s 30
java Driver -e -t s -r 100 -c 35 -s 35
java Driver -e -t s -r 100 -c 40 -s 40
java Driver -e -t s -r 100 -c 45 -s 45
java Driver -e -t s -r 100 -c 50 -s 50
java Driver -e -t s -r 100 -c 55 -s 55
java Driver -e -t s -r 100 -c 60 -s 60
java Driver -e -t s -r 100 -c 65 -s 65
java Driver -e -t s -r 100 -c 70 -s 70
java Driver -e -t s -r 100 -c 75 -s 75
java Driver -e -t s -r 100 -c 80 -s 80
java Driver -e -t s -r 100 -c 85 -s 85
java Driver -e -t s -r 100 -c 90 -s 90
java Driver -e -t s -r 100 -c 95 -s 95
java Driver -e -t s -r 100 -c 100 -s 100
echo "CSCAN"
java Driver -e -t c -r 100 -c 5 -s 5
java Driver -e -t c -r 100 -c 10 -s 10
java Driver -e -t c -r 100 -c 15 -s 15
java Driver -e -t c -r 100 -c 20 -s 20
java Driver -e -t c -r 100 -c 25 -s 25
java Driver -e -t c -r 100 -c 30 -s 30
java Driver -e -t c -r 100 -c 35 -s 35
java Driver -e -t c -r 100 -c 40 -s 40
java Driver -e -t c -r 100 -c 45 -s 45
java Driver -e -t c -r 100 -c 50 -s 50
java Driver -e -t c -r 100 -c 55 -s 55
java Driver -e -t c -r 100 -c 60 -s 60
java Driver -e -t c -r 100 -c 65 -s 65
java Driver -e -t c -r 100 -c 70 -s 70
java Driver -e -t c -r 100 -c 75 -s 75
java Driver -e -t c -r 100 -c 80 -s 80
java Driver -e -t c -r 100 -c 85 -s 85
java Driver -e -t c -r 100 -c 90 -s 90
java Driver -e -t c -r 100 -c 95 -s 95
java Driver -e -t c -r 100 -c 100 -s 100
