#!/bin/bash
# Varying the requests only.
echo "SST"
java Driver -e -t s -r 10
java Driver -e -t s -r 20
java Driver -e -t s -r 30
java Driver -e -t s -r 40
java Driver -e -t s -r 50
java Driver -e -t s -r 60
java Driver -e -t s -r 70
java Driver -e -t s -r 80
java Driver -e -t s -r 90
java Driver -e -t s -r 100
java Driver -e -t s -r 110
java Driver -e -t s -r 120
java Driver -e -t s -r 130
java Driver -e -t s -r 140
java Driver -e -t s -r 150
java Driver -e -t s -r 160
java Driver -e -t s -r 170
java Driver -e -t s -r 180
java Driver -e -t s -r 190
java Driver -e -t s -r 200
echo "CSCAN"
java Driver -e -t c -r 10
java Driver -e -t c -r 20
java Driver -e -t c -r 30
java Driver -e -t c -r 40
java Driver -e -t c -r 50
java Driver -e -t c -r 60
java Driver -e -t c -r 70
java Driver -e -t c -r 80
java Driver -e -t c -r 90
java Driver -e -t c -r 100
java Driver -e -t c -r 110
java Driver -e -t c -r 120
java Driver -e -t c -r 130
java Driver -e -t c -r 140
java Driver -e -t c -r 150
java Driver -e -t c -r 160
java Driver -e -t c -r 170
java Driver -e -t c -r 180
java Driver -e -t c -r 190
java Driver -e -t c -r 200
