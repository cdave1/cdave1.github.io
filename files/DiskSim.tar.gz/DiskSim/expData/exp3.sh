#!/bin/bash
# Varying number of clients, keeping servers at 3
echo "SST"
java Driver -e -t s -r 100 -c 5 -s 5
java Driver -e -t s -r 100 -c 10 -s 5
java Driver -e -t s -r 100 -c 15 -s 5
java Driver -e -t s -r 100 -c 20 -s 5
java Driver -e -t s -r 100 -c 25 -s 5
java Driver -e -t s -r 100 -c 30 -s 5
java Driver -e -t s -r 100 -c 35 -s 5
java Driver -e -t s -r 100 -c 40 -s 5
java Driver -e -t s -r 100 -c 45 -s 5
java Driver -e -t s -r 100 -c 50 -s 5
java Driver -e -t s -r 100 -c 55 -s 5
java Driver -e -t s -r 100 -c 60 -s 5
java Driver -e -t s -r 100 -c 65 -s 5
java Driver -e -t s -r 100 -c 70 -s 5
java Driver -e -t s -r 100 -c 75 -s 5
java Driver -e -t s -r 100 -c 80 -s 5
java Driver -e -t s -r 100 -c 85 -s 5
java Driver -e -t s -r 100 -c 90 -s 5
java Driver -e -t s -r 100 -c 95 -s 5
java Driver -e -t s -r 100 -c 100 -s 5
echo "CSCAN"
java Driver -e -t c -r 100 -c 5 -s 5
java Driver -e -t c -r 100 -c 10 -s 5
java Driver -e -t c -r 100 -c 15 -s 5
java Driver -e -t c -r 100 -c 20 -s 5
java Driver -e -t c -r 100 -c 25 -s 5
java Driver -e -t c -r 100 -c 30 -s 5
java Driver -e -t c -r 100 -c 35 -s 5
java Driver -e -t c -r 100 -c 40 -s 5
java Driver -e -t c -r 100 -c 45 -s 5
java Driver -e -t c -r 100 -c 50 -s 5
java Driver -e -t c -r 100 -c 55 -s 5
java Driver -e -t c -r 100 -c 60 -s 5
java Driver -e -t c -r 100 -c 65 -s 5
java Driver -e -t c -r 100 -c 70 -s 5
java Driver -e -t c -r 100 -c 75 -s 5
java Driver -e -t c -r 100 -c 80 -s 5
java Driver -e -t c -r 100 -c 85 -s 5
java Driver -e -t c -r 100 -c 90 -s 5
java Driver -e -t c -r 100 -c 95 -s 5
java Driver -e -t c -r 100 -c 100 -s 5
