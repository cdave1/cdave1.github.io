#!/bin/bash
# Increasing cylinder size
echo "SST"
java Driver -e -t s -r 100 -y 500
java Driver -e -t s -r 100 -y 1000
java Driver -e -t s -r 100 -y 1500
java Driver -e -t s -r 100 -y 2000
java Driver -e -t s -r 100 -y 2500
java Driver -e -t s -r 100 -y 3000
java Driver -e -t s -r 100 -y 3500
java Driver -e -t s -r 100 -y 4000
java Driver -e -t s -r 100 -y 4500
java Driver -e -t s -r 100 -y 5000
java Driver -e -t s -r 100 -y 5500
java Driver -e -t s -r 100 -y 6000
java Driver -e -t s -r 100 -y 6500
java Driver -e -t s -r 100 -y 7000
java Driver -e -t s -r 100 -y 7500
java Driver -e -t s -r 100 -y 8000
java Driver -e -t s -r 100 -y 8500
java Driver -e -t s -r 100 -y 9000
java Driver -e -t s -r 100 -y 9500
java Driver -e -t s -r 100 -y 10000
echo "CSCAN"
java Driver -e -t c -r 100 -y 500
java Driver -e -t c -r 100 -y 1000
java Driver -e -t c -r 100 -y 1500
java Driver -e -t c -r 100 -y 2000
java Driver -e -t c -r 100 -y 2500
java Driver -e -t c -r 100 -y 3000
java Driver -e -t c -r 100 -y 3500
java Driver -e -t c -r 100 -y 4000
java Driver -e -t c -r 100 -y 4500
java Driver -e -t c -r 100 -y 5000
java Driver -e -t c -r 100 -y 5500
java Driver -e -t c -r 100 -y 6000
java Driver -e -t c -r 100 -y 6500
java Driver -e -t c -r 100 -y 7000
java Driver -e -t c -r 100 -y 7500
java Driver -e -t c -r 100 -y 8000
java Driver -e -t c -r 100 -y 8500
java Driver -e -t c -r 100 -y 9000
java Driver -e -t c -r 100 -y 9500
java Driver -e -t c -r 100 -y 10000
